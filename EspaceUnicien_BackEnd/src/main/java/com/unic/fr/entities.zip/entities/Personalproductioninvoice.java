package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the personalproductioninvoice database table.
 * 
 */
@Entity
@NamedQuery(name="Personalproductioninvoice.findAll", query="SELECT p FROM Personalproductioninvoice p")
public class Personalproductioninvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PERSONALPRODUCTIONINVOICE_IDPERSONALPRODUCTIONINVOICE_GENERATOR", sequenceName="GUF.PERSONALPRODUCTIONINVOICE_IDPERSONALPRODUCTIONINVOICE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PERSONALPRODUCTIONINVOICE_IDPERSONALPRODUCTIONINVOICE_GENERATOR")
	private Integer idpersonalproductioninvoice;

	private String currency;

	private byte[] document;

	@Temporal(TemporalType.DATE)
	private Date duedate;

	private String personalproductioninvoicereferencenumber;

	private float taxamount;

	private float taxrate;

	private float totalamountwithouttax;

	private float totalamountwithtax;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="personalproductioninvoice")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Personalprodpinvoicestatushistory
	@OneToMany(mappedBy="personalproductioninvoice")
	private Set<Personalprodpinvoicestatushistory> personalprodpinvoicestatushistories;

	//bi-directional many-to-one association to Groupcompany
	@ManyToOne
	@JoinColumn(name="idrecipient")
	private Groupcompany groupcompany;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idissuer")
	private Partner partner;

	public Personalproductioninvoice() {
	}

	public Integer getIdpersonalproductioninvoice() {
		return this.idpersonalproductioninvoice;
	}

	public void setIdpersonalproductioninvoice(Integer idpersonalproductioninvoice) {
		this.idpersonalproductioninvoice = idpersonalproductioninvoice;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public Date getDuedate() {
		return this.duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public String getPersonalproductioninvoicereferencenumber() {
		return this.personalproductioninvoicereferencenumber;
	}

	public void setPersonalproductioninvoicereferencenumber(String personalproductioninvoicereferencenumber) {
		this.personalproductioninvoicereferencenumber = personalproductioninvoicereferencenumber;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public float getTotalamountwithouttax() {
		return this.totalamountwithouttax;
	}

	public void setTotalamountwithouttax(float totalamountwithouttax) {
		this.totalamountwithouttax = totalamountwithouttax;
	}

	public float getTotalamountwithtax() {
		return this.totalamountwithtax;
	}

	public void setTotalamountwithtax(float totalamountwithtax) {
		this.totalamountwithtax = totalamountwithtax;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setPersonalproductioninvoice(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setPersonalproductioninvoice(null);

		return customerinvoice;
	}

	public Set<Personalprodpinvoicestatushistory> getPersonalprodpinvoicestatushistories() {
		return this.personalprodpinvoicestatushistories;
	}

	public void setPersonalprodpinvoicestatushistories(Set<Personalprodpinvoicestatushistory> personalprodpinvoicestatushistories) {
		this.personalprodpinvoicestatushistories = personalprodpinvoicestatushistories;
	}

	public Personalprodpinvoicestatushistory addPersonalprodpinvoicestatushistory(Personalprodpinvoicestatushistory personalprodpinvoicestatushistory) {
		getPersonalprodpinvoicestatushistories().add(personalprodpinvoicestatushistory);
		personalprodpinvoicestatushistory.setPersonalproductioninvoice(this);

		return personalprodpinvoicestatushistory;
	}

	public Personalprodpinvoicestatushistory removePersonalprodpinvoicestatushistory(Personalprodpinvoicestatushistory personalprodpinvoicestatushistory) {
		getPersonalprodpinvoicestatushistories().remove(personalprodpinvoicestatushistory);
		personalprodpinvoicestatushistory.setPersonalproductioninvoice(null);

		return personalprodpinvoicestatushistory;
	}

	public Groupcompany getGroupcompany() {
		return this.groupcompany;
	}

	public void setGroupcompany(Groupcompany groupcompany) {
		this.groupcompany = groupcompany;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

}