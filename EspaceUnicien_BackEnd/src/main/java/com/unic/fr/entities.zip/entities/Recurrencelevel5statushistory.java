package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the recurrencelevel5statushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel5statushistory.findAll", query="SELECT r FROM Recurrencelevel5statushistory r")
public class Recurrencelevel5statushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL5STATUSHISTORY_IDRECLEVEL5STATUSHISTORY_GENERATOR", sequenceName="GUF.RECURRENCELEVEL5STATUSHISTORY_IDRECLEVEL5STATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL5STATUSHISTORY_IDRECLEVEL5STATUSHISTORY_GENERATOR")
	private Integer idreclevel5statushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Recurrencelevel5
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel5")
	private Recurrencelevel5 recurrencelevel5;

	public Recurrencelevel5statushistory() {
	}

	public Integer getIdreclevel5statushistory() {
		return this.idreclevel5statushistory;
	}

	public void setIdreclevel5statushistory(Integer idreclevel5statushistory) {
		this.idreclevel5statushistory = idreclevel5statushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Recurrencelevel5 getRecurrencelevel5() {
		return this.recurrencelevel5;
	}

	public void setRecurrencelevel5(Recurrencelevel5 recurrencelevel5) {
		this.recurrencelevel5 = recurrencelevel5;
	}

}