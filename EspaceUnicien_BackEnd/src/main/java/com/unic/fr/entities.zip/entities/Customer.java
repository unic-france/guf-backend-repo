package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the customer database table.
 * 
 */
@Entity
@NamedQuery(name="Customer.findAll", query="SELECT c FROM Customer c")
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CUSTOMER_IDCUSTOMER_GENERATOR", sequenceName="GUF.CUSTOMER_IDCUSTOMER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CUSTOMER_IDCUSTOMER_GENERATOR")
	private Integer idcustomer;

	private String companyname;

	private String referencenumber;

	private String sector;

	private String siren;

	//bi-directional many-to-one association to Assignment
	@OneToMany(mappedBy="customer1")
	private Set<Assignment> assignments1;

	//bi-directional many-to-one association to Assignment
	@OneToMany(mappedBy="customer2")
	private Set<Assignment> assignments2;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idaddressheadoffice")
	private Address address;

	//bi-directional many-to-one association to Customercontact
	@OneToMany(mappedBy="customer")
	private Set<Customercontact> customercontacts;

	public Customer() {
	}

	public Integer getIdcustomer() {
		return this.idcustomer;
	}

	public void setIdcustomer(Integer idcustomer) {
		this.idcustomer = idcustomer;
	}

	public String getCompanyname() {
		return this.companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getReferencenumber() {
		return this.referencenumber;
	}

	public void setReferencenumber(String referencenumber) {
		this.referencenumber = referencenumber;
	}

	public String getSector() {
		return this.sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getSiren() {
		return this.siren;
	}

	public void setSiren(String siren) {
		this.siren = siren;
	}

	public Set<Assignment> getAssignments1() {
		return this.assignments1;
	}

	public void setAssignments1(Set<Assignment> assignments1) {
		this.assignments1 = assignments1;
	}

	public Assignment addAssignments1(Assignment assignments1) {
		getAssignments1().add(assignments1);
		assignments1.setCustomer1(this);

		return assignments1;
	}

	public Assignment removeAssignments1(Assignment assignments1) {
		getAssignments1().remove(assignments1);
		assignments1.setCustomer1(null);

		return assignments1;
	}

	public Set<Assignment> getAssignments2() {
		return this.assignments2;
	}

	public void setAssignments2(Set<Assignment> assignments2) {
		this.assignments2 = assignments2;
	}

	public Assignment addAssignments2(Assignment assignments2) {
		getAssignments2().add(assignments2);
		assignments2.setCustomer2(this);

		return assignments2;
	}

	public Assignment removeAssignments2(Assignment assignments2) {
		getAssignments2().remove(assignments2);
		assignments2.setCustomer2(null);

		return assignments2;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Set<Customercontact> getCustomercontacts() {
		return this.customercontacts;
	}

	public void setCustomercontacts(Set<Customercontact> customercontacts) {
		this.customercontacts = customercontacts;
	}

	public Customercontact addCustomercontact(Customercontact customercontact) {
		getCustomercontacts().add(customercontact);
		customercontact.setCustomer(this);

		return customercontact;
	}

	public Customercontact removeCustomercontact(Customercontact customercontact) {
		getCustomercontacts().remove(customercontact);
		customercontact.setCustomer(null);

		return customercontact;
	}

}