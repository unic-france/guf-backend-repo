package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the assignmentstatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Assignmentstatushistory.findAll", query="SELECT a FROM Assignmentstatushistory a")
public class Assignmentstatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ASSIGNMENTSTATUSHISTORY_IDASSIGNMENTSTATUSHISTORY_GENERATOR", sequenceName="GUF.ASSIGNMENTSTATUSHISTORY_IDASSIGNMENTSTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ASSIGNMENTSTATUSHISTORY_IDASSIGNMENTSTATUSHISTORY_GENERATOR")
	private Integer idassignmentstatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Assignment
	@ManyToOne
	@JoinColumn(name="idassignment")
	private Assignment assignment;

	public Assignmentstatushistory() {
	}

	public Integer getIdassignmentstatushistory() {
		return this.idassignmentstatushistory;
	}

	public void setIdassignmentstatushistory(Integer idassignmentstatushistory) {
		this.idassignmentstatushistory = idassignmentstatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Assignment getAssignment() {
		return this.assignment;
	}

	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}

}