package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the pack database table.
 * 
 */
@Entity
@NamedQuery(name="Pack.findAll", query="SELECT p FROM Pack p")
public class Pack implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PACK_IDPACK_GENERATOR", sequenceName="GUF.PACK_IDPACK_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PACK_IDPACK_GENERATOR")
	private Integer idpack;

	private String billingperiodicity;

	private String currency;

	private String description;

	private String packreference;

	private float pricewithouttax;

	private float pricewithtax;

	private String shortdescription;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Packpartner
	@OneToMany(mappedBy="pack")
	private Set<Packpartner> packpartners;

	public Pack() {
	}

	public Integer getIdpack() {
		return this.idpack;
	}

	public void setIdpack(Integer idpack) {
		this.idpack = idpack;
	}

	public String getBillingperiodicity() {
		return this.billingperiodicity;
	}

	public void setBillingperiodicity(String billingperiodicity) {
		this.billingperiodicity = billingperiodicity;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPackreference() {
		return this.packreference;
	}

	public void setPackreference(String packreference) {
		this.packreference = packreference;
	}

	public float getPricewithouttax() {
		return this.pricewithouttax;
	}

	public void setPricewithouttax(float pricewithouttax) {
		this.pricewithouttax = pricewithouttax;
	}

	public float getPricewithtax() {
		return this.pricewithtax;
	}

	public void setPricewithtax(float pricewithtax) {
		this.pricewithtax = pricewithtax;
	}

	public String getShortdescription() {
		return this.shortdescription;
	}

	public void setShortdescription(String shortdescription) {
		this.shortdescription = shortdescription;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Set<Packpartner> getPackpartners() {
		return this.packpartners;
	}

	public void setPackpartners(Set<Packpartner> packpartners) {
		this.packpartners = packpartners;
	}

	public Packpartner addPackpartner(Packpartner packpartner) {
		getPackpartners().add(packpartner);
		packpartner.setPack(this);

		return packpartner;
	}

	public Packpartner removePackpartner(Packpartner packpartner) {
		getPackpartners().remove(packpartner);
		packpartner.setPack(null);

		return packpartner;
	}

}