package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the qualificationpartner database table.
 * 
 */
@Entity
@NamedQuery(name="Qualificationpartner.findAll", query="SELECT q FROM Qualificationpartner q")
public class Qualificationpartner implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private QualificationpartnerPK id;

	private Boolean current;

	private Timestamp date;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartner",insertable=false, updatable=false)
	private Partner partner;

	//bi-directional many-to-one association to Qualification
	@ManyToOne
	@JoinColumn(name="idqualification",insertable=false, updatable=false)
	private Qualification qualification;

	public Qualificationpartner() {
	}

	public QualificationpartnerPK getId() {
		return this.id;
	}

	public void setId(QualificationpartnerPK id) {
		this.id = id;
	}

	public Boolean getCurrent() {
		return this.current;
	}

	public void setCurrent(Boolean current) {
		this.current = current;
	}

	public Timestamp getDate() {
		return this.date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public Qualification getQualification() {
		return this.qualification;
	}

	public void setQualification(Qualification qualification) {
		this.qualification = qualification;
	}

}