package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the gridpourcentagerepartitionpartner database table.
 * 
 */
@Entity
@NamedQuery(name="Gridpourcentagerepartitionpartner.findAll", query="SELECT g FROM Gridpourcentagerepartitionpartner g")
public class Gridpourcentagerepartitionpartner implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GRIDPOURCENTAGEREPARTITIONPARTNER_IDGRIDPOURCENTAGEREPPART_GENERATOR", sequenceName="GUF.GRIDPOURCENTAGEREPARTITIONPARTNER_IDGRIDPOURCENTAGEREPPART_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GRIDPOURCENTAGEREPARTITIONPARTNER_IDGRIDPOURCENTAGEREPPART_GENERATOR")
	private Integer idgridpourcentagereppart;

	private Boolean current;

	private Timestamp date;

	//bi-directional many-to-one association to Businessopportunitybrought
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Businessopportunitybrought> businessopportunitybroughts;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Gridpourcentagerepartition
	@ManyToOne
	@JoinColumn(name="idgridpourcentagerepartition")
	private Gridpourcentagerepartition gridpourcentagerepartition;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartner")
	private Partner partner;

	//bi-directional many-to-one association to Groupmodel
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Groupmodel> groupmodels;

	//bi-directional many-to-one association to Recurrencegroup
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Recurrencegroup> recurrencegroups;

	//bi-directional many-to-one association to Recurrencelevel1
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Recurrencelevel1> recurrencelevel1s;

	//bi-directional many-to-one association to Recurrencelevel2
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Recurrencelevel2> recurrencelevel2s;

	//bi-directional many-to-one association to Recurrencelevel3
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Recurrencelevel3> recurrencelevel3s;

	//bi-directional many-to-one association to Recurrencelevel4
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Recurrencelevel4> recurrencelevel4s;

	//bi-directional many-to-one association to Recurrencelevel5
	@OneToMany(mappedBy="gridpourcentagerepartitionpartner")
	private Set<Recurrencelevel5> recurrencelevel5s;

	public Gridpourcentagerepartitionpartner() {
	}

	public Integer getIdgridpourcentagereppart() {
		return this.idgridpourcentagereppart;
	}

	public void setIdgridpourcentagereppart(Integer idgridpourcentagereppart) {
		this.idgridpourcentagereppart = idgridpourcentagereppart;
	}

	public Boolean getCurrent() {
		return this.current;
	}

	public void setCurrent(Boolean current) {
		this.current = current;
	}

	public Timestamp getDate() {
		return this.date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public Set<Businessopportunitybrought> getBusinessopportunitybroughts() {
		return this.businessopportunitybroughts;
	}

	public void setBusinessopportunitybroughts(Set<Businessopportunitybrought> businessopportunitybroughts) {
		this.businessopportunitybroughts = businessopportunitybroughts;
	}

	public Businessopportunitybrought addBusinessopportunitybrought(Businessopportunitybrought businessopportunitybrought) {
		getBusinessopportunitybroughts().add(businessopportunitybrought);
		businessopportunitybrought.setGridpourcentagerepartitionpartner(this);

		return businessopportunitybrought;
	}

	public Businessopportunitybrought removeBusinessopportunitybrought(Businessopportunitybrought businessopportunitybrought) {
		getBusinessopportunitybroughts().remove(businessopportunitybrought);
		businessopportunitybrought.setGridpourcentagerepartitionpartner(null);

		return businessopportunitybrought;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setGridpourcentagerepartitionpartner(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setGridpourcentagerepartitionpartner(null);

		return customerinvoice;
	}

	public Gridpourcentagerepartition getGridpourcentagerepartition() {
		return this.gridpourcentagerepartition;
	}

	public void setGridpourcentagerepartition(Gridpourcentagerepartition gridpourcentagerepartition) {
		this.gridpourcentagerepartition = gridpourcentagerepartition;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public Set<Groupmodel> getGroupmodels() {
		return this.groupmodels;
	}

	public void setGroupmodels(Set<Groupmodel> groupmodels) {
		this.groupmodels = groupmodels;
	}

	public Groupmodel addGroupmodel(Groupmodel groupmodel) {
		getGroupmodels().add(groupmodel);
		groupmodel.setGridpourcentagerepartitionpartner(this);

		return groupmodel;
	}

	public Groupmodel removeGroupmodel(Groupmodel groupmodel) {
		getGroupmodels().remove(groupmodel);
		groupmodel.setGridpourcentagerepartitionpartner(null);

		return groupmodel;
	}

	public Set<Recurrencegroup> getRecurrencegroups() {
		return this.recurrencegroups;
	}

	public void setRecurrencegroups(Set<Recurrencegroup> recurrencegroups) {
		this.recurrencegroups = recurrencegroups;
	}

	public Recurrencegroup addRecurrencegroup(Recurrencegroup recurrencegroup) {
		getRecurrencegroups().add(recurrencegroup);
		recurrencegroup.setGridpourcentagerepartitionpartner(this);

		return recurrencegroup;
	}

	public Recurrencegroup removeRecurrencegroup(Recurrencegroup recurrencegroup) {
		getRecurrencegroups().remove(recurrencegroup);
		recurrencegroup.setGridpourcentagerepartitionpartner(null);

		return recurrencegroup;
	}

	public Set<Recurrencelevel1> getRecurrencelevel1s() {
		return this.recurrencelevel1s;
	}

	public void setRecurrencelevel1s(Set<Recurrencelevel1> recurrencelevel1s) {
		this.recurrencelevel1s = recurrencelevel1s;
	}

	public Recurrencelevel1 addRecurrencelevel1(Recurrencelevel1 recurrencelevel1) {
		getRecurrencelevel1s().add(recurrencelevel1);
		recurrencelevel1.setGridpourcentagerepartitionpartner(this);

		return recurrencelevel1;
	}

	public Recurrencelevel1 removeRecurrencelevel1(Recurrencelevel1 recurrencelevel1) {
		getRecurrencelevel1s().remove(recurrencelevel1);
		recurrencelevel1.setGridpourcentagerepartitionpartner(null);

		return recurrencelevel1;
	}

	public Set<Recurrencelevel2> getRecurrencelevel2s() {
		return this.recurrencelevel2s;
	}

	public void setRecurrencelevel2s(Set<Recurrencelevel2> recurrencelevel2s) {
		this.recurrencelevel2s = recurrencelevel2s;
	}

	public Recurrencelevel2 addRecurrencelevel2(Recurrencelevel2 recurrencelevel2) {
		getRecurrencelevel2s().add(recurrencelevel2);
		recurrencelevel2.setGridpourcentagerepartitionpartner(this);

		return recurrencelevel2;
	}

	public Recurrencelevel2 removeRecurrencelevel2(Recurrencelevel2 recurrencelevel2) {
		getRecurrencelevel2s().remove(recurrencelevel2);
		recurrencelevel2.setGridpourcentagerepartitionpartner(null);

		return recurrencelevel2;
	}

	public Set<Recurrencelevel3> getRecurrencelevel3s() {
		return this.recurrencelevel3s;
	}

	public void setRecurrencelevel3s(Set<Recurrencelevel3> recurrencelevel3s) {
		this.recurrencelevel3s = recurrencelevel3s;
	}

	public Recurrencelevel3 addRecurrencelevel3(Recurrencelevel3 recurrencelevel3) {
		getRecurrencelevel3s().add(recurrencelevel3);
		recurrencelevel3.setGridpourcentagerepartitionpartner(this);

		return recurrencelevel3;
	}

	public Recurrencelevel3 removeRecurrencelevel3(Recurrencelevel3 recurrencelevel3) {
		getRecurrencelevel3s().remove(recurrencelevel3);
		recurrencelevel3.setGridpourcentagerepartitionpartner(null);

		return recurrencelevel3;
	}

	public Set<Recurrencelevel4> getRecurrencelevel4s() {
		return this.recurrencelevel4s;
	}

	public void setRecurrencelevel4s(Set<Recurrencelevel4> recurrencelevel4s) {
		this.recurrencelevel4s = recurrencelevel4s;
	}

	public Recurrencelevel4 addRecurrencelevel4(Recurrencelevel4 recurrencelevel4) {
		getRecurrencelevel4s().add(recurrencelevel4);
		recurrencelevel4.setGridpourcentagerepartitionpartner(this);

		return recurrencelevel4;
	}

	public Recurrencelevel4 removeRecurrencelevel4(Recurrencelevel4 recurrencelevel4) {
		getRecurrencelevel4s().remove(recurrencelevel4);
		recurrencelevel4.setGridpourcentagerepartitionpartner(null);

		return recurrencelevel4;
	}

	public Set<Recurrencelevel5> getRecurrencelevel5s() {
		return this.recurrencelevel5s;
	}

	public void setRecurrencelevel5s(Set<Recurrencelevel5> recurrencelevel5s) {
		this.recurrencelevel5s = recurrencelevel5s;
	}

	public Recurrencelevel5 addRecurrencelevel5(Recurrencelevel5 recurrencelevel5) {
		getRecurrencelevel5s().add(recurrencelevel5);
		recurrencelevel5.setGridpourcentagerepartitionpartner(this);

		return recurrencelevel5;
	}

	public Recurrencelevel5 removeRecurrencelevel5(Recurrencelevel5 recurrencelevel5) {
		getRecurrencelevel5s().remove(recurrencelevel5);
		recurrencelevel5.setGridpourcentagerepartitionpartner(null);

		return recurrencelevel5;
	}

}