package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the recurrencegroup database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencegroup.findAll", query="SELECT r FROM Recurrencegroup r")
public class Recurrencegroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCEGROUP_IDRECURRENCEGROUP_GENERATOR", sequenceName="GUF.RECURRENCEGROUP_IDRECURRENCEGROUP_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCEGROUP_IDRECURRENCEGROUP_GENERATOR")
	private Integer idrecurrencegroup;

	private float amountwithouttax;

	private float amountwithtax;

	private String currency;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="recurrencegroup")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Partnernetwork
	@ManyToOne
	@JoinColumn(name="idpartnernetwork")
	private Partnernetwork partnernetwork;

	//bi-directional many-to-one association to Recurrencegroupstatushistory
	@OneToMany(mappedBy="recurrencegroup")
	private Set<Recurrencegroupstatushistory> recurrencegroupstatushistories;

	public Recurrencegroup() {
	}

	public Integer getIdrecurrencegroup() {
		return this.idrecurrencegroup;
	}

	public void setIdrecurrencegroup(Integer idrecurrencegroup) {
		this.idrecurrencegroup = idrecurrencegroup;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setRecurrencegroup(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setRecurrencegroup(null);

		return customerinvoice;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Partnernetwork getPartnernetwork() {
		return this.partnernetwork;
	}

	public void setPartnernetwork(Partnernetwork partnernetwork) {
		this.partnernetwork = partnernetwork;
	}

	public Set<Recurrencegroupstatushistory> getRecurrencegroupstatushistories() {
		return this.recurrencegroupstatushistories;
	}

	public void setRecurrencegroupstatushistories(Set<Recurrencegroupstatushistory> recurrencegroupstatushistories) {
		this.recurrencegroupstatushistories = recurrencegroupstatushistories;
	}

	public Recurrencegroupstatushistory addRecurrencegroupstatushistory(Recurrencegroupstatushistory recurrencegroupstatushistory) {
		getRecurrencegroupstatushistories().add(recurrencegroupstatushistory);
		recurrencegroupstatushistory.setRecurrencegroup(this);

		return recurrencegroupstatushistory;
	}

	public Recurrencegroupstatushistory removeRecurrencegroupstatushistory(Recurrencegroupstatushistory recurrencegroupstatushistory) {
		getRecurrencegroupstatushistories().remove(recurrencegroupstatushistory);
		recurrencegroupstatushistory.setRecurrencegroup(null);

		return recurrencegroupstatushistory;
	}

}