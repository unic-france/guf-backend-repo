package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the recurrencelevel4 database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel4.findAll", query="SELECT r FROM Recurrencelevel4 r")
public class Recurrencelevel4 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL4_IDRECURRENCELEVEL4_GENERATOR", sequenceName="GUF.RECURRENCELEVEL4_IDRECURRENCELEVEL4_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL4_IDRECURRENCELEVEL4_GENERATOR")
	private Integer idrecurrencelevel4;

	private float amountwithouttax;

	private float amountwithtax;

	private Boolean capitalized;

	private String currency;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="recurrencelevel4")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Partnernetwork
	@ManyToOne
	@JoinColumn(name="idpartnernetwork")
	private Partnernetwork partnernetwork;

	//bi-directional many-to-many association to Recurrenceinvoice
	@ManyToMany
	@JoinTable(
		name="recurrenceinvoicereccurencelevel4"
		, joinColumns={
			@JoinColumn(name="idrecurrencelevel4")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idreccurenceinvoice")
			}
		)
	private Set<Recurrenceinvoice> recurrenceinvoices;

	//bi-directional many-to-one association to Recurrencelevel4statushistory
	@OneToMany(mappedBy="recurrencelevel4")
	private Set<Recurrencelevel4statushistory> recurrencelevel4statushistories;

	public Recurrencelevel4() {
	}

	public Integer getIdrecurrencelevel4() {
		return this.idrecurrencelevel4;
	}

	public void setIdrecurrencelevel4(Integer idrecurrencelevel4) {
		this.idrecurrencelevel4 = idrecurrencelevel4;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public Boolean getCapitalized() {
		return this.capitalized;
	}

	public void setCapitalized(Boolean capitalized) {
		this.capitalized = capitalized;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setRecurrencelevel4(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setRecurrencelevel4(null);

		return customerinvoice;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Partnernetwork getPartnernetwork() {
		return this.partnernetwork;
	}

	public void setPartnernetwork(Partnernetwork partnernetwork) {
		this.partnernetwork = partnernetwork;
	}

	public Set<Recurrenceinvoice> getRecurrenceinvoices() {
		return this.recurrenceinvoices;
	}

	public void setRecurrenceinvoices(Set<Recurrenceinvoice> recurrenceinvoices) {
		this.recurrenceinvoices = recurrenceinvoices;
	}

	public Set<Recurrencelevel4statushistory> getRecurrencelevel4statushistories() {
		return this.recurrencelevel4statushistories;
	}

	public void setRecurrencelevel4statushistories(Set<Recurrencelevel4statushistory> recurrencelevel4statushistories) {
		this.recurrencelevel4statushistories = recurrencelevel4statushistories;
	}

	public Recurrencelevel4statushistory addRecurrencelevel4statushistory(Recurrencelevel4statushistory recurrencelevel4statushistory) {
		getRecurrencelevel4statushistories().add(recurrencelevel4statushistory);
		recurrencelevel4statushistory.setRecurrencelevel4(this);

		return recurrencelevel4statushistory;
	}

	public Recurrencelevel4statushistory removeRecurrencelevel4statushistory(Recurrencelevel4statushistory recurrencelevel4statushistory) {
		getRecurrencelevel4statushistories().remove(recurrencelevel4statushistory);
		recurrencelevel4statushistory.setRecurrencelevel4(null);

		return recurrencelevel4statushistory;
	}

}