package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the groupcompany database table.
 * 
 */
@Entity
@NamedQuery(name="Groupcompany.findAll", query="SELECT g FROM Groupcompany g")
public class Groupcompany implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPCOMPANY_IDGROUPCOMPANY_GENERATOR", sequenceName="GUF.GROUPCOMPANY_IDGROUPCOMPANY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPCOMPANY_IDGROUPCOMPANY_GENERATOR")
	private Integer idgroupcompany;

	private Boolean active;

	private String groupcompanyname;

	private String sirennumber;

	private String siretnumber;

	private String tvanumber;

	//bi-directional many-to-one association to Businessopportunitybroughtinvoice
	@OneToMany(mappedBy="groupcompany")
	private Set<Businessopportunitybroughtinvoice> businessopportunitybroughtinvoices;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="groupcompany")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idgroupbillingaddress",insertable=false, updatable=false)
	private Address address1;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idgroupbillingaddress",insertable=false, updatable=false)
	private Address address2;

	//bi-directional many-to-one association to Groupbankingdetail
	@ManyToOne
	@JoinColumn(name="idgroupbankingdetails",insertable=false, updatable=false)
	private Groupbankingdetail groupbankingdetail;

	//bi-directional many-to-one association to Groupbillingcontact
	@ManyToOne
	@JoinColumn(name="idgroupbillingcontact",insertable=false, updatable=false)
	private Groupbillingcontact groupbillingcontact;

	//bi-directional many-to-one association to Packinvoice
	@OneToMany(mappedBy="groupcompany")
	private Set<Packinvoice> packinvoices;

	//bi-directional many-to-one association to Personalproductioninvoice
	@OneToMany(mappedBy="groupcompany")
	private Set<Personalproductioninvoice> personalproductioninvoices;

	//bi-directional many-to-one association to Recurrenceinvoice
	@OneToMany(mappedBy="groupcompany")
	private Set<Recurrenceinvoice> recurrenceinvoices;

	public Groupcompany() {
	}

	public Integer getIdgroupcompany() {
		return this.idgroupcompany;
	}

	public void setIdgroupcompany(Integer idgroupcompany) {
		this.idgroupcompany = idgroupcompany;
	}

	public Boolean getActive() {
		return this.active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getGroupcompanyname() {
		return this.groupcompanyname;
	}

	public void setGroupcompanyname(String groupcompanyname) {
		this.groupcompanyname = groupcompanyname;
	}

	public String getSirennumber() {
		return this.sirennumber;
	}

	public void setSirennumber(String sirennumber) {
		this.sirennumber = sirennumber;
	}

	public String getSiretnumber() {
		return this.siretnumber;
	}

	public void setSiretnumber(String siretnumber) {
		this.siretnumber = siretnumber;
	}

	public String getTvanumber() {
		return this.tvanumber;
	}

	public void setTvanumber(String tvanumber) {
		this.tvanumber = tvanumber;
	}

	public Set<Businessopportunitybroughtinvoice> getBusinessopportunitybroughtinvoices() {
		return this.businessopportunitybroughtinvoices;
	}

	public void setBusinessopportunitybroughtinvoices(Set<Businessopportunitybroughtinvoice> businessopportunitybroughtinvoices) {
		this.businessopportunitybroughtinvoices = businessopportunitybroughtinvoices;
	}

	public Businessopportunitybroughtinvoice addBusinessopportunitybroughtinvoice(Businessopportunitybroughtinvoice businessopportunitybroughtinvoice) {
		getBusinessopportunitybroughtinvoices().add(businessopportunitybroughtinvoice);
		businessopportunitybroughtinvoice.setGroupcompany(this);

		return businessopportunitybroughtinvoice;
	}

	public Businessopportunitybroughtinvoice removeBusinessopportunitybroughtinvoice(Businessopportunitybroughtinvoice businessopportunitybroughtinvoice) {
		getBusinessopportunitybroughtinvoices().remove(businessopportunitybroughtinvoice);
		businessopportunitybroughtinvoice.setGroupcompany(null);

		return businessopportunitybroughtinvoice;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setGroupcompany(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setGroupcompany(null);

		return customerinvoice;
	}

	public Address getAddress1() {
		return this.address1;
	}

	public void setAddress1(Address address1) {
		this.address1 = address1;
	}

	public Address getAddress2() {
		return this.address2;
	}

	public void setAddress2(Address address2) {
		this.address2 = address2;
	}

	public Groupbankingdetail getGroupbankingdetail() {
		return this.groupbankingdetail;
	}

	public void setGroupbankingdetail(Groupbankingdetail groupbankingdetail) {
		this.groupbankingdetail = groupbankingdetail;
	}

	public Groupbillingcontact getGroupbillingcontact() {
		return this.groupbillingcontact;
	}

	public void setGroupbillingcontact(Groupbillingcontact groupbillingcontact) {
		this.groupbillingcontact = groupbillingcontact;
	}

	public Set<Packinvoice> getPackinvoices() {
		return this.packinvoices;
	}

	public void setPackinvoices(Set<Packinvoice> packinvoices) {
		this.packinvoices = packinvoices;
	}

	public Packinvoice addPackinvoice(Packinvoice packinvoice) {
		getPackinvoices().add(packinvoice);
		packinvoice.setGroupcompany(this);

		return packinvoice;
	}

	public Packinvoice removePackinvoice(Packinvoice packinvoice) {
		getPackinvoices().remove(packinvoice);
		packinvoice.setGroupcompany(null);

		return packinvoice;
	}

	public Set<Personalproductioninvoice> getPersonalproductioninvoices() {
		return this.personalproductioninvoices;
	}

	public void setPersonalproductioninvoices(Set<Personalproductioninvoice> personalproductioninvoices) {
		this.personalproductioninvoices = personalproductioninvoices;
	}

	public Personalproductioninvoice addPersonalproductioninvoice(Personalproductioninvoice personalproductioninvoice) {
		getPersonalproductioninvoices().add(personalproductioninvoice);
		personalproductioninvoice.setGroupcompany(this);

		return personalproductioninvoice;
	}

	public Personalproductioninvoice removePersonalproductioninvoice(Personalproductioninvoice personalproductioninvoice) {
		getPersonalproductioninvoices().remove(personalproductioninvoice);
		personalproductioninvoice.setGroupcompany(null);

		return personalproductioninvoice;
	}

	public Set<Recurrenceinvoice> getRecurrenceinvoices() {
		return this.recurrenceinvoices;
	}

	public void setRecurrenceinvoices(Set<Recurrenceinvoice> recurrenceinvoices) {
		this.recurrenceinvoices = recurrenceinvoices;
	}

	public Recurrenceinvoice addRecurrenceinvoice(Recurrenceinvoice recurrenceinvoice) {
		getRecurrenceinvoices().add(recurrenceinvoice);
		recurrenceinvoice.setGroupcompany(this);

		return recurrenceinvoice;
	}

	public Recurrenceinvoice removeRecurrenceinvoice(Recurrenceinvoice recurrenceinvoice) {
		getRecurrenceinvoices().remove(recurrenceinvoice);
		recurrenceinvoice.setGroupcompany(null);

		return recurrenceinvoice;
	}

}