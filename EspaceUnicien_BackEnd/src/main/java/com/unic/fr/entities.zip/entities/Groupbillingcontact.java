package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the groupbillingcontact database table.
 * 
 */
@Entity
@NamedQuery(name="Groupbillingcontact.findAll", query="SELECT g FROM Groupbillingcontact g")
public class Groupbillingcontact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPBILLINGCONTACT_IDGROUPBILLINGCONTACT_GENERATOR", sequenceName="GUF.GROUPBILLINGCONTACT_IDGROUPBILLINGCONTACT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPBILLINGCONTACT_IDGROUPBILLINGCONTACT_GENERATOR")
	private Integer idgroupbillingcontact;

	private String groupbillingemailcontact;

	private String groupbillingphonecontact;

	//bi-directional many-to-one association to Groupcompany
	@OneToMany(mappedBy="groupbillingcontact")
	private Set<Groupcompany> groupcompanies;

	public Groupbillingcontact() {
	}

	public Integer getIdgroupbillingcontact() {
		return this.idgroupbillingcontact;
	}

	public void setIdgroupbillingcontact(Integer idgroupbillingcontact) {
		this.idgroupbillingcontact = idgroupbillingcontact;
	}

	public String getGroupbillingemailcontact() {
		return this.groupbillingemailcontact;
	}

	public void setGroupbillingemailcontact(String groupbillingemailcontact) {
		this.groupbillingemailcontact = groupbillingemailcontact;
	}

	public String getGroupbillingphonecontact() {
		return this.groupbillingphonecontact;
	}

	public void setGroupbillingphonecontact(String groupbillingphonecontact) {
		this.groupbillingphonecontact = groupbillingphonecontact;
	}

	public Set<Groupcompany> getGroupcompanies() {
		return this.groupcompanies;
	}

	public void setGroupcompanies(Set<Groupcompany> groupcompanies) {
		this.groupcompanies = groupcompanies;
	}

	public Groupcompany addGroupcompany(Groupcompany groupcompany) {
		getGroupcompanies().add(groupcompany);
		groupcompany.setGroupbillingcontact(this);

		return groupcompany;
	}

	public Groupcompany removeGroupcompany(Groupcompany groupcompany) {
		getGroupcompanies().remove(groupcompany);
		groupcompany.setGroupbillingcontact(null);

		return groupcompany;
	}

}