package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the groupstaffmember database table.
 * 
 */
@Entity
@NamedQuery(name="Groupstaffmember.findAll", query="SELECT g FROM Groupstaffmember g")
public class Groupstaffmember implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPSTAFFMEMBER_IDGROUPSTAFFMEMBER_GENERATOR", sequenceName="GUF.GROUPSTAFFMEMBER_IDGROUPSTAFFMEMBER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPSTAFFMEMBER_IDGROUPSTAFFMEMBER_GENERATOR")
	private Integer idgroupstaffmember;

	private Timestamp datecreation;

	private String guid;

	private String status;

	//bi-directional many-to-one association to Connexionhistorygroupstaffmember
	@OneToMany(mappedBy="groupstaffmember")
	private Set<Connexionhistorygroupstaffmember> connexionhistorygroupstaffmembers;

	//bi-directional many-to-many association to Assignment
	@ManyToMany
	@JoinTable(
		name="assignementgroupstaffmember"
		, joinColumns={
			@JoinColumn(name="idgroupstaffmember")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idassignment")
			}
		)
	private Set<Assignment> assignments;

	//bi-directional many-to-one association to Groupstaffmemberprofile
	@ManyToOne
	@JoinColumn(name="idgroupstaffmemberprofile")
	private Groupstaffmemberprofile groupstaffmemberprofile;

	//bi-directional many-to-many association to Partner
	@ManyToMany(mappedBy="groupstaffmembers")
	private Set<Partner> partners;

	public Groupstaffmember() {
	}

	public Integer getIdgroupstaffmember() {
		return this.idgroupstaffmember;
	}

	public void setIdgroupstaffmember(Integer idgroupstaffmember) {
		this.idgroupstaffmember = idgroupstaffmember;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getGuid() {
		return this.guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<Connexionhistorygroupstaffmember> getConnexionhistorygroupstaffmembers() {
		return this.connexionhistorygroupstaffmembers;
	}

	public void setConnexionhistorygroupstaffmembers(Set<Connexionhistorygroupstaffmember> connexionhistorygroupstaffmembers) {
		this.connexionhistorygroupstaffmembers = connexionhistorygroupstaffmembers;
	}

	public Connexionhistorygroupstaffmember addConnexionhistorygroupstaffmember(Connexionhistorygroupstaffmember connexionhistorygroupstaffmember) {
		getConnexionhistorygroupstaffmembers().add(connexionhistorygroupstaffmember);
		connexionhistorygroupstaffmember.setGroupstaffmember(this);

		return connexionhistorygroupstaffmember;
	}

	public Connexionhistorygroupstaffmember removeConnexionhistorygroupstaffmember(Connexionhistorygroupstaffmember connexionhistorygroupstaffmember) {
		getConnexionhistorygroupstaffmembers().remove(connexionhistorygroupstaffmember);
		connexionhistorygroupstaffmember.setGroupstaffmember(null);

		return connexionhistorygroupstaffmember;
	}

	public Set<Assignment> getAssignments() {
		return this.assignments;
	}

	public void setAssignments(Set<Assignment> assignments) {
		this.assignments = assignments;
	}

	public Groupstaffmemberprofile getGroupstaffmemberprofile() {
		return this.groupstaffmemberprofile;
	}

	public void setGroupstaffmemberprofile(Groupstaffmemberprofile groupstaffmemberprofile) {
		this.groupstaffmemberprofile = groupstaffmemberprofile;
	}

	public Set<Partner> getPartners() {
		return this.partners;
	}

	public void setPartners(Set<Partner> partners) {
		this.partners = partners;
	}

}