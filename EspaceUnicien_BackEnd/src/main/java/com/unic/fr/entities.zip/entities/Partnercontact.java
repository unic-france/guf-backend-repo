package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the partnercontact database table.
 * 
 */
@Entity
@NamedQuery(name="Partnercontact.findAll", query="SELECT p FROM Partnercontact p")
public class Partnercontact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNERCONTACT_IDPARTNERCONTACT_GENERATOR", sequenceName="GUF.PARTNERCONTACT_IDPARTNERCONTACT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNERCONTACT_IDPARTNERCONTACT_GENERATOR")
	private Integer idpartnercontact;

	private String emailgroup;

	private String emailpartner;

	private String mobilephonenumber;

	private String phonenumber;

	//bi-directional many-to-one association to Partnerprofile
	@OneToMany(mappedBy="partnercontact")
	private Set<Partnerprofile> partnerprofiles;

	public Partnercontact() {
	}

	public Integer getIdpartnercontact() {
		return this.idpartnercontact;
	}

	public void setIdpartnercontact(Integer idpartnercontact) {
		this.idpartnercontact = idpartnercontact;
	}

	public String getEmailgroup() {
		return this.emailgroup;
	}

	public void setEmailgroup(String emailgroup) {
		this.emailgroup = emailgroup;
	}

	public String getEmailpartner() {
		return this.emailpartner;
	}

	public void setEmailpartner(String emailpartner) {
		this.emailpartner = emailpartner;
	}

	public String getMobilephonenumber() {
		return this.mobilephonenumber;
	}

	public void setMobilephonenumber(String mobilephonenumber) {
		this.mobilephonenumber = mobilephonenumber;
	}

	public String getPhonenumber() {
		return this.phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Set<Partnerprofile> getPartnerprofiles() {
		return this.partnerprofiles;
	}

	public void setPartnerprofiles(Set<Partnerprofile> partnerprofiles) {
		this.partnerprofiles = partnerprofiles;
	}

	public Partnerprofile addPartnerprofile(Partnerprofile partnerprofile) {
		getPartnerprofiles().add(partnerprofile);
		partnerprofile.setPartnercontact(this);

		return partnerprofile;
	}

	public Partnerprofile removePartnerprofile(Partnerprofile partnerprofile) {
		getPartnerprofiles().remove(partnerprofile);
		partnerprofile.setPartnercontact(null);

		return partnerprofile;
	}

}