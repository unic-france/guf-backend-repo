package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the partnercompany database table.
 * 
 */
@Entity
@NamedQuery(name="Partnercompany.findAll", query="SELECT p FROM Partnercompany p")
public class Partnercompany implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNERCOMPANY_IDPARTNERCOMPANY_GENERATOR", sequenceName="GUF.PARTNERCOMPANY_IDPARTNERCOMPANY_SEQ" , allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNERCOMPANY_IDPARTNERCOMPANY_GENERATOR")
	private Integer idpartnercompany;

	private String apecode;

	private String companyname;

	@Temporal(TemporalType.DATE)
	private Date datejoingroup;

	@Temporal(TemporalType.DATE)
	private Date dateofcreation;

	private String description;

	private Boolean existingbeforejoininggroup;

	private String legalstatus;

	private String nafcode;

	private String sharecapital;

	private String sirennumber;

	private String siretnumber;

	private String tvanumber;

	//bi-directional many-to-one association to Partner
	@OneToMany(mappedBy="partnercompany")
	private Set<Partner> partners;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idaddressbilling")
	private Address address1;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idaddressheadoffice")
	private Address address2;

	public Partnercompany() {
	}

	public Integer getIdpartnercompany() {
		return this.idpartnercompany;
	}

	public void setIdpartnercompany(Integer idpartnercompany) {
		this.idpartnercompany = idpartnercompany;
	}

	public String getApecode() {
		return this.apecode;
	}

	public void setApecode(String apecode) {
		this.apecode = apecode;
	}

	public String getCompanyname() {
		return this.companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public Date getDatejoingroup() {
		return this.datejoingroup;
	}

	public void setDatejoingroup(Date datejoingroup) {
		this.datejoingroup = datejoingroup;
	}

	public Date getDateofcreation() {
		return this.dateofcreation;
	}

	public void setDateofcreation(Date dateofcreation) {
		this.dateofcreation = dateofcreation;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getExistingbeforejoininggroup() {
		return this.existingbeforejoininggroup;
	}

	public void setExistingbeforejoininggroup(Boolean existingbeforejoininggroup) {
		this.existingbeforejoininggroup = existingbeforejoininggroup;
	}

	public String getLegalstatus() {
		return this.legalstatus;
	}

	public void setLegalstatus(String legalstatus) {
		this.legalstatus = legalstatus;
	}

	public String getNafcode() {
		return this.nafcode;
	}

	public void setNafcode(String nafcode) {
		this.nafcode = nafcode;
	}

	public String getSharecapital() {
		return this.sharecapital;
	}

	public void setSharecapital(String sharecapital) {
		this.sharecapital = sharecapital;
	}

	public String getSirennumber() {
		return this.sirennumber;
	}

	public void setSirennumber(String sirennumber) {
		this.sirennumber = sirennumber;
	}

	public String getSiretnumber() {
		return this.siretnumber;
	}

	public void setSiretnumber(String siretnumber) {
		this.siretnumber = siretnumber;
	}

	public String getTvanumber() {
		return this.tvanumber;
	}

	public void setTvanumber(String tvanumber) {
		this.tvanumber = tvanumber;
	}

	public Set<Partner> getPartners() {
		return this.partners;
	}

	public void setPartners(Set<Partner> partners) {
		this.partners = partners;
	}

	public Partner addPartner(Partner partner) {
		getPartners().add(partner);
		partner.setPartnercompany(this);

		return partner;
	}

	public Partner removePartner(Partner partner) {
		getPartners().remove(partner);
		partner.setPartnercompany(null);

		return partner;
	}

	public Address getAddress1() {
		return this.address1;
	}

	public void setAddress1(Address address1) {
		this.address1 = address1;
	}

	public Address getAddress2() {
		return this.address2;
	}

	public void setAddress2(Address address2) {
		this.address2 = address2;
	}

}