package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the recurrencegroupstatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencegroupstatushistory.findAll", query="SELECT r FROM Recurrencegroupstatushistory r")
public class Recurrencegroupstatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCEGROUPSTATUSHISTORY_IDRECGROUPSTATUSHISTORY_GENERATOR", sequenceName="GUF.RECURRENCEGROUPSTATUSHISTORY_IDRECGROUPSTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCEGROUPSTATUSHISTORY_IDRECGROUPSTATUSHISTORY_GENERATOR")
	private Integer idrecgroupstatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Recurrencegroup
	@ManyToOne
	@JoinColumn(name="idrecurrencegroup")
	private Recurrencegroup recurrencegroup;

	public Recurrencegroupstatushistory() {
	}

	public Integer getIdrecgroupstatushistory() {
		return this.idrecgroupstatushistory;
	}

	public void setIdrecgroupstatushistory(Integer idrecgroupstatushistory) {
		this.idrecgroupstatushistory = idrecgroupstatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Recurrencegroup getRecurrencegroup() {
		return this.recurrencegroup;
	}

	public void setRecurrencegroup(Recurrencegroup recurrencegroup) {
		this.recurrencegroup = recurrencegroup;
	}

}