package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the address database table.
 * 
 */
@Entity
@NamedQuery(name="Address.findAll", query="SELECT a FROM Address a")
public class Address implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ADDRESS_IDADDRESS_GENERATOR", sequenceName="GUF.ADDRESS_IDADDRESS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ADDRESS_IDADDRESS_GENERATOR")
	private Integer idaddress;

	private String line1recipient;

	private String line2deliverypoint;

	private String line3additionallocalizationinfo;

	private String line4streetnumberandstreetlabel;

	private String line5additionalstreetinfo;

	private String line6zipcodelocalization;

	private String line7country;

	//bi-directional many-to-one association to Assignment
	@OneToMany(mappedBy="address")
	private Set<Assignment> assignments;

	//bi-directional many-to-one association to Customer
	@OneToMany(mappedBy="address")
	private Set<Customer> customers;

	//bi-directional many-to-one association to Customercontact
	@OneToMany(mappedBy="address")
	private Set<Customercontact> customercontacts;

	//bi-directional many-to-one association to Customerinvoicedetail
	@OneToMany(mappedBy="address")
	private Set<Customerinvoicedetail> customerinvoicedetails;

	//bi-directional many-to-one association to Groupcompany
	@OneToMany(mappedBy="address1")
	private Set<Groupcompany> groupcompanies1;

	//bi-directional many-to-one association to Groupcompany
	@OneToMany(mappedBy="address2")
	private Set<Groupcompany> groupcompanies2;

	//bi-directional many-to-one association to Partnerbankingdetail
	@OneToMany(mappedBy="address")
	private Set<Partnerbankingdetail> partnerbankingdetails;

	//bi-directional many-to-one association to Partnercompany
	@OneToMany(mappedBy="address1")
	private Set<Partnercompany> partnercompanies1;

	//bi-directional many-to-one association to Partnercompany
	@OneToMany(mappedBy="address2")
	private Set<Partnercompany> partnercompanies2;

	public Address() {
	}

	public Integer getIdaddress() {
		return this.idaddress;
	}

	public void setIdaddress(Integer idaddress) {
		this.idaddress = idaddress;
	}

	public String getLine1recipient() {
		return this.line1recipient;
	}

	public void setLine1recipient(String line1recipient) {
		this.line1recipient = line1recipient;
	}

	public String getLine2deliverypoint() {
		return this.line2deliverypoint;
	}

	public void setLine2deliverypoint(String line2deliverypoint) {
		this.line2deliverypoint = line2deliverypoint;
	}

	public String getLine3additionallocalizationinfo() {
		return this.line3additionallocalizationinfo;
	}

	public void setLine3additionallocalizationinfo(String line3additionallocalizationinfo) {
		this.line3additionallocalizationinfo = line3additionallocalizationinfo;
	}

	public String getLine4streetnumberandstreetlabel() {
		return this.line4streetnumberandstreetlabel;
	}

	public void setLine4streetnumberandstreetlabel(String line4streetnumberandstreetlabel) {
		this.line4streetnumberandstreetlabel = line4streetnumberandstreetlabel;
	}

	public String getLine5additionalstreetinfo() {
		return this.line5additionalstreetinfo;
	}

	public void setLine5additionalstreetinfo(String line5additionalstreetinfo) {
		this.line5additionalstreetinfo = line5additionalstreetinfo;
	}

	public String getLine6zipcodelocalization() {
		return this.line6zipcodelocalization;
	}

	public void setLine6zipcodelocalization(String line6zipcodelocalization) {
		this.line6zipcodelocalization = line6zipcodelocalization;
	}

	public String getLine7country() {
		return this.line7country;
	}

	public void setLine7country(String line7country) {
		this.line7country = line7country;
	}

	public Set<Assignment> getAssignments() {
		return this.assignments;
	}

	public void setAssignments(Set<Assignment> assignments) {
		this.assignments = assignments;
	}

	public Assignment addAssignment(Assignment assignment) {
		getAssignments().add(assignment);
		assignment.setAddress(this);

		return assignment;
	}

	public Assignment removeAssignment(Assignment assignment) {
		getAssignments().remove(assignment);
		assignment.setAddress(null);

		return assignment;
	}

	public Set<Customer> getCustomers() {
		return this.customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	public Customer addCustomer(Customer customer) {
		getCustomers().add(customer);
		customer.setAddress(this);

		return customer;
	}

	public Customer removeCustomer(Customer customer) {
		getCustomers().remove(customer);
		customer.setAddress(null);

		return customer;
	}

	public Set<Customercontact> getCustomercontacts() {
		return this.customercontacts;
	}

	public void setCustomercontacts(Set<Customercontact> customercontacts) {
		this.customercontacts = customercontacts;
	}

	public Customercontact addCustomercontact(Customercontact customercontact) {
		getCustomercontacts().add(customercontact);
		customercontact.setAddress(this);

		return customercontact;
	}

	public Customercontact removeCustomercontact(Customercontact customercontact) {
		getCustomercontacts().remove(customercontact);
		customercontact.setAddress(null);

		return customercontact;
	}

	public Set<Customerinvoicedetail> getCustomerinvoicedetails() {
		return this.customerinvoicedetails;
	}

	public void setCustomerinvoicedetails(Set<Customerinvoicedetail> customerinvoicedetails) {
		this.customerinvoicedetails = customerinvoicedetails;
	}

	public Customerinvoicedetail addCustomerinvoicedetail(Customerinvoicedetail customerinvoicedetail) {
		getCustomerinvoicedetails().add(customerinvoicedetail);
		customerinvoicedetail.setAddress(this);

		return customerinvoicedetail;
	}

	public Customerinvoicedetail removeCustomerinvoicedetail(Customerinvoicedetail customerinvoicedetail) {
		getCustomerinvoicedetails().remove(customerinvoicedetail);
		customerinvoicedetail.setAddress(null);

		return customerinvoicedetail;
	}

	public Set<Groupcompany> getGroupcompanies1() {
		return this.groupcompanies1;
	}

	public void setGroupcompanies1(Set<Groupcompany> groupcompanies1) {
		this.groupcompanies1 = groupcompanies1;
	}

	public Groupcompany addGroupcompanies1(Groupcompany groupcompanies1) {
		getGroupcompanies1().add(groupcompanies1);
		groupcompanies1.setAddress1(this);

		return groupcompanies1;
	}

	public Groupcompany removeGroupcompanies1(Groupcompany groupcompanies1) {
		getGroupcompanies1().remove(groupcompanies1);
		groupcompanies1.setAddress1(null);

		return groupcompanies1;
	}

	public Set<Groupcompany> getGroupcompanies2() {
		return this.groupcompanies2;
	}

	public void setGroupcompanies2(Set<Groupcompany> groupcompanies2) {
		this.groupcompanies2 = groupcompanies2;
	}

	public Groupcompany addGroupcompanies2(Groupcompany groupcompanies2) {
		getGroupcompanies2().add(groupcompanies2);
		groupcompanies2.setAddress2(this);

		return groupcompanies2;
	}

	public Groupcompany removeGroupcompanies2(Groupcompany groupcompanies2) {
		getGroupcompanies2().remove(groupcompanies2);
		groupcompanies2.setAddress2(null);

		return groupcompanies2;
	}

	public Set<Partnerbankingdetail> getPartnerbankingdetails() {
		return this.partnerbankingdetails;
	}

	public void setPartnerbankingdetails(Set<Partnerbankingdetail> partnerbankingdetails) {
		this.partnerbankingdetails = partnerbankingdetails;
	}

	public Partnerbankingdetail addPartnerbankingdetail(Partnerbankingdetail partnerbankingdetail) {
		getPartnerbankingdetails().add(partnerbankingdetail);
		partnerbankingdetail.setAddress(this);

		return partnerbankingdetail;
	}

	public Partnerbankingdetail removePartnerbankingdetail(Partnerbankingdetail partnerbankingdetail) {
		getPartnerbankingdetails().remove(partnerbankingdetail);
		partnerbankingdetail.setAddress(null);

		return partnerbankingdetail;
	}

	public Set<Partnercompany> getPartnercompanies1() {
		return this.partnercompanies1;
	}

	public void setPartnercompanies1(Set<Partnercompany> partnercompanies1) {
		this.partnercompanies1 = partnercompanies1;
	}

	public Partnercompany addPartnercompanies1(Partnercompany partnercompanies1) {
		getPartnercompanies1().add(partnercompanies1);
		partnercompanies1.setAddress1(this);

		return partnercompanies1;
	}

	public Partnercompany removePartnercompanies1(Partnercompany partnercompanies1) {
		getPartnercompanies1().remove(partnercompanies1);
		partnercompanies1.setAddress1(null);

		return partnercompanies1;
	}

	public Set<Partnercompany> getPartnercompanies2() {
		return this.partnercompanies2;
	}

	public void setPartnercompanies2(Set<Partnercompany> partnercompanies2) {
		this.partnercompanies2 = partnercompanies2;
	}

	public Partnercompany addPartnercompanies2(Partnercompany partnercompanies2) {
		getPartnercompanies2().add(partnercompanies2);
		partnercompanies2.setAddress2(this);

		return partnercompanies2;
	}

	public Partnercompany removePartnercompanies2(Partnercompany partnercompanies2) {
		getPartnercompanies2().remove(partnercompanies2);
		partnercompanies2.setAddress2(null);

		return partnercompanies2;
	}

}