package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the businessopportunitybroughtinvoice database table.
 * 
 */
@Entity
@NamedQuery(name="Businessopportunitybroughtinvoice.findAll", query="SELECT b FROM Businessopportunitybroughtinvoice b")
public class Businessopportunitybroughtinvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="BUSINESSOPPORTUNITYBROUGHTINVOICE_IDBOBINVOICE_GENERATOR", sequenceName="GUF.BUSINESSOPPORTUNITYBROUGHTINVOICE_IDBOBINVOICE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BUSINESSOPPORTUNITYBROUGHTINVOICE_IDBOBINVOICE_GENERATOR")
	private Integer idbobinvoice;

	private String businessbroughtinvoicereferencenumber;

	private String currency;

	private byte[] document;

	@Temporal(TemporalType.DATE)
	private Date duedate;

	private float taxamount;

	private float taxrate;

	private float totalamountwithouttax;

	private float totalamountwithtax;

	//bi-directional many-to-one association to Bobinvoicestatushistory
	@OneToMany(mappedBy="businessopportunitybroughtinvoice")
	private Set<Bobinvoicestatushistory> bobinvoicestatushistories;

	//bi-directional many-to-many association to Businessopportunitybrought
	@ManyToMany
	@JoinTable(
		name="bobinvoicebob"
		, joinColumns={
			@JoinColumn(name="idbobinvoice")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idbusinessopportunitybrought")
			}
		)
	private Set<Businessopportunitybrought> businessopportunitybroughts;

	//bi-directional many-to-one association to Groupcompany
	@ManyToOne
	@JoinColumn(name="idrecipient")
	private Groupcompany groupcompany;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idissuer")
	private Partner partner;

	public Businessopportunitybroughtinvoice() {
	}

	public Integer getIdbobinvoice() {
		return this.idbobinvoice;
	}

	public void setIdbobinvoice(Integer idbobinvoice) {
		this.idbobinvoice = idbobinvoice;
	}

	public String getBusinessbroughtinvoicereferencenumber() {
		return this.businessbroughtinvoicereferencenumber;
	}

	public void setBusinessbroughtinvoicereferencenumber(String businessbroughtinvoicereferencenumber) {
		this.businessbroughtinvoicereferencenumber = businessbroughtinvoicereferencenumber;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public Date getDuedate() {
		return this.duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public float getTotalamountwithouttax() {
		return this.totalamountwithouttax;
	}

	public void setTotalamountwithouttax(float totalamountwithouttax) {
		this.totalamountwithouttax = totalamountwithouttax;
	}

	public float getTotalamountwithtax() {
		return this.totalamountwithtax;
	}

	public void setTotalamountwithtax(float totalamountwithtax) {
		this.totalamountwithtax = totalamountwithtax;
	}

	public Set<Bobinvoicestatushistory> getBobinvoicestatushistories() {
		return this.bobinvoicestatushistories;
	}

	public void setBobinvoicestatushistories(Set<Bobinvoicestatushistory> bobinvoicestatushistories) {
		this.bobinvoicestatushistories = bobinvoicestatushistories;
	}

	public Bobinvoicestatushistory addBobinvoicestatushistory(Bobinvoicestatushistory bobinvoicestatushistory) {
		getBobinvoicestatushistories().add(bobinvoicestatushistory);
		bobinvoicestatushistory.setBusinessopportunitybroughtinvoice(this);

		return bobinvoicestatushistory;
	}

	public Bobinvoicestatushistory removeBobinvoicestatushistory(Bobinvoicestatushistory bobinvoicestatushistory) {
		getBobinvoicestatushistories().remove(bobinvoicestatushistory);
		bobinvoicestatushistory.setBusinessopportunitybroughtinvoice(null);

		return bobinvoicestatushistory;
	}

	public Set<Businessopportunitybrought> getBusinessopportunitybroughts() {
		return this.businessopportunitybroughts;
	}

	public void setBusinessopportunitybroughts(Set<Businessopportunitybrought> businessopportunitybroughts) {
		this.businessopportunitybroughts = businessopportunitybroughts;
	}

	public Groupcompany getGroupcompany() {
		return this.groupcompany;
	}

	public void setGroupcompany(Groupcompany groupcompany) {
		this.groupcompany = groupcompany;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

}