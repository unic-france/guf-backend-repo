package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the recurrencelevel2statushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel2statushistory.findAll", query="SELECT r FROM Recurrencelevel2statushistory r")
public class Recurrencelevel2statushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL2STATUSHISTORY_IDRECLEVEL2STATUSHISTORY_GENERATOR", sequenceName="GUF.RECURRENCELEVEL2STATUSHISTORY_IDRECLEVEL2STATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL2STATUSHISTORY_IDRECLEVEL2STATUSHISTORY_GENERATOR")
	private Integer idreclevel2statushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Recurrencelevel2
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel2")
	private Recurrencelevel2 recurrencelevel2;

	public Recurrencelevel2statushistory() {
	}

	public Integer getIdreclevel2statushistory() {
		return this.idreclevel2statushistory;
	}

	public void setIdreclevel2statushistory(Integer idreclevel2statushistory) {
		this.idreclevel2statushistory = idreclevel2statushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Recurrencelevel2 getRecurrencelevel2() {
		return this.recurrencelevel2;
	}

	public void setRecurrencelevel2(Recurrencelevel2 recurrencelevel2) {
		this.recurrencelevel2 = recurrencelevel2;
	}

}