package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the customerinvoicedetails database table.
 * 
 */
@Entity
@Table(name="customerinvoicedetails")
@NamedQuery(name="Customerinvoicedetail.findAll", query="SELECT c FROM Customerinvoicedetail c")
public class Customerinvoicedetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CUSTOMERINVOICEDETAILS_IDCUSTOMERINVOICEDETAILS_GENERATOR", sequenceName="GUF.CUSTOMERINVOICEDETAILS_IDCUSTOMERINVOICEDETAILS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CUSTOMERINVOICEDETAILS_IDCUSTOMERINVOICEDETAILS_GENERATOR")
	private Integer idcustomerinvoicedetails;

	private String invoiceassignmentreferencenumber;

	private String invoicetype;

	//bi-directional many-to-one association to Assignment
	@OneToMany(mappedBy="customerinvoicedetail")
	private Set<Assignment> assignments;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="customerinvoicedetail")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idrecipientbillingaddress")
	private Address address;

	public Customerinvoicedetail() {
	}

	public Integer getIdcustomerinvoicedetails() {
		return this.idcustomerinvoicedetails;
	}

	public void setIdcustomerinvoicedetails(Integer idcustomerinvoicedetails) {
		this.idcustomerinvoicedetails = idcustomerinvoicedetails;
	}

	public String getInvoiceassignmentreferencenumber() {
		return this.invoiceassignmentreferencenumber;
	}

	public void setInvoiceassignmentreferencenumber(String invoiceassignmentreferencenumber) {
		this.invoiceassignmentreferencenumber = invoiceassignmentreferencenumber;
	}

	public String getInvoicetype() {
		return this.invoicetype;
	}

	public void setInvoicetype(String invoicetype) {
		this.invoicetype = invoicetype;
	}

	public Set<Assignment> getAssignments() {
		return this.assignments;
	}

	public void setAssignments(Set<Assignment> assignments) {
		this.assignments = assignments;
	}

	public Assignment addAssignment(Assignment assignment) {
		getAssignments().add(assignment);
		assignment.setCustomerinvoicedetail(this);

		return assignment;
	}

	public Assignment removeAssignment(Assignment assignment) {
		getAssignments().remove(assignment);
		assignment.setCustomerinvoicedetail(null);

		return assignment;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setCustomerinvoicedetail(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setCustomerinvoicedetail(null);

		return customerinvoice;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}