package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the packinvoice database table.
 * 
 */
@Entity
@NamedQuery(name="Packinvoice.findAll", query="SELECT p FROM Packinvoice p")
public class Packinvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PACKINVOICE_IDPACKINVOICE_GENERATOR", sequenceName="GUF.PACKINVOICE_IDPACKINVOICE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PACKINVOICE_IDPACKINVOICE_GENERATOR")
	private Integer idpackinvoice;

	private String currency;

	private byte[] document;

	@Temporal(TemporalType.DATE)
	private Date duedate;

	private String packinvoicereferencenumber;

	private float taxrate;

	private float totalamountwithouttax;

	private float totalamountwithtax;

	private float totaltaxamount;

	//bi-directional many-to-one association to Groupcompany
	@ManyToOne
	@JoinColumn(name="idissuer")
	private Groupcompany groupcompany;

	//bi-directional many-to-one association to Packpartner
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="idpack", referencedColumnName="idpartner"),
		@JoinColumn(name="idrecipient", referencedColumnName="idpack")
		})
	private Packpartner packpartner;

	//bi-directional many-to-one association to Packinvoicestatushistory
	@OneToMany(mappedBy="packinvoice")
	private Set<Packinvoicestatushistory> packinvoicestatushistories;

	public Packinvoice() {
	}

	public Integer getIdpackinvoice() {
		return this.idpackinvoice;
	}

	public void setIdpackinvoice(Integer idpackinvoice) {
		this.idpackinvoice = idpackinvoice;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public Date getDuedate() {
		return this.duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public String getPackinvoicereferencenumber() {
		return this.packinvoicereferencenumber;
	}

	public void setPackinvoicereferencenumber(String packinvoicereferencenumber) {
		this.packinvoicereferencenumber = packinvoicereferencenumber;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public float getTotalamountwithouttax() {
		return this.totalamountwithouttax;
	}

	public void setTotalamountwithouttax(float totalamountwithouttax) {
		this.totalamountwithouttax = totalamountwithouttax;
	}

	public float getTotalamountwithtax() {
		return this.totalamountwithtax;
	}

	public void setTotalamountwithtax(float totalamountwithtax) {
		this.totalamountwithtax = totalamountwithtax;
	}

	public float getTotaltaxamount() {
		return this.totaltaxamount;
	}

	public void setTotaltaxamount(float totaltaxamount) {
		this.totaltaxamount = totaltaxamount;
	}

	public Groupcompany getGroupcompany() {
		return this.groupcompany;
	}

	public void setGroupcompany(Groupcompany groupcompany) {
		this.groupcompany = groupcompany;
	}

	public Packpartner getPackpartner() {
		return this.packpartner;
	}

	public void setPackpartner(Packpartner packpartner) {
		this.packpartner = packpartner;
	}

	public Set<Packinvoicestatushistory> getPackinvoicestatushistories() {
		return this.packinvoicestatushistories;
	}

	public void setPackinvoicestatushistories(Set<Packinvoicestatushistory> packinvoicestatushistories) {
		this.packinvoicestatushistories = packinvoicestatushistories;
	}

	public Packinvoicestatushistory addPackinvoicestatushistory(Packinvoicestatushistory packinvoicestatushistory) {
		getPackinvoicestatushistories().add(packinvoicestatushistory);
		packinvoicestatushistory.setPackinvoice(this);

		return packinvoicestatushistory;
	}

	public Packinvoicestatushistory removePackinvoicestatushistory(Packinvoicestatushistory packinvoicestatushistory) {
		getPackinvoicestatushistories().remove(packinvoicestatushistory);
		packinvoicestatushistory.setPackinvoice(null);

		return packinvoicestatushistory;
	}

}