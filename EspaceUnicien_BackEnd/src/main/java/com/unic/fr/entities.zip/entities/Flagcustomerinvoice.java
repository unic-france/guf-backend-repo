package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the flagcustomerinvoice database table.
 * 
 */
@Entity
@NamedQuery(name="Flagcustomerinvoice.findAll", query="SELECT f FROM Flagcustomerinvoice f")
public class Flagcustomerinvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="FLAGCUSTOMERINVOICE_IDFLAGCUSTOMERINVOICE_GENERATOR", sequenceName="GUF.FLAGCUSTOMERINVOICE_IDFLAGCUSTOMERINVOICE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="FLAGCUSTOMERINVOICE_IDFLAGCUSTOMERINVOICE_GENERATOR")
	private Integer idflagcustomerinvoice;

	private String flagcheckrepartitioninvoice;

	private Boolean flagrepartitioninvoice;

	private Boolean flagrepartitioninvoicepaid;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="flagcustomerinvoice")
	private Set<Customerinvoice> customerinvoices;

	public Flagcustomerinvoice() {
	}

	public Integer getIdflagcustomerinvoice() {
		return this.idflagcustomerinvoice;
	}

	public void setIdflagcustomerinvoice(Integer idflagcustomerinvoice) {
		this.idflagcustomerinvoice = idflagcustomerinvoice;
	}

	public String getFlagcheckrepartitioninvoice() {
		return this.flagcheckrepartitioninvoice;
	}

	public void setFlagcheckrepartitioninvoice(String flagcheckrepartitioninvoice) {
		this.flagcheckrepartitioninvoice = flagcheckrepartitioninvoice;
	}

	public Boolean getFlagrepartitioninvoice() {
		return this.flagrepartitioninvoice;
	}

	public void setFlagrepartitioninvoice(Boolean flagrepartitioninvoice) {
		this.flagrepartitioninvoice = flagrepartitioninvoice;
	}

	public Boolean getFlagrepartitioninvoicepaid() {
		return this.flagrepartitioninvoicepaid;
	}

	public void setFlagrepartitioninvoicepaid(Boolean flagrepartitioninvoicepaid) {
		this.flagrepartitioninvoicepaid = flagrepartitioninvoicepaid;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setFlagcustomerinvoice(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setFlagcustomerinvoice(null);

		return customerinvoice;
	}

}