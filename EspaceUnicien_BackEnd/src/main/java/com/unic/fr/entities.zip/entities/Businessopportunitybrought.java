package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the businessopportunitybrought database table.
 * 
 */
@Entity
@NamedQuery(name="Businessopportunitybrought.findAll", query="SELECT b FROM Businessopportunitybrought b")
public class Businessopportunitybrought implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="BUSINESSOPPORTUNITYBROUGHT_IDBUSINESSOPPORTUNITYBROUGHT_GENERATOR", sequenceName="GUF.BUSINESSOPPORTUNITYBROUGHT_IDBUSINESSOPPORTUNITYBROUGHT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BUSINESSOPPORTUNITYBROUGHT_IDBUSINESSOPPORTUNITYBROUGHT_GENERATOR")
	private Integer idbusinessopportunitybrought;

	private float amountwithouttax;

	private float amountwithtax;

	private String currency;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartnerbusinessopportunitybrought")
	private Partner partner;

	//bi-directional many-to-many association to Businessopportunitybroughtinvoice
	@ManyToMany(mappedBy="businessopportunitybroughts")
	private Set<Businessopportunitybroughtinvoice> businessopportunitybroughtinvoices;

	//bi-directional many-to-one association to Businessopportunitybroughtstatushistory
	@OneToMany(mappedBy="businessopportunitybrought")
	private Set<Businessopportunitybroughtstatushistory> businessopportunitybroughtstatushistories;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="businessopportunitybrought")
	private Set<Customerinvoice> customerinvoices;

	public Businessopportunitybrought() {
	}

	public Integer getIdbusinessopportunitybrought() {
		return this.idbusinessopportunitybrought;
	}

	public void setIdbusinessopportunitybrought(Integer idbusinessopportunitybrought) {
		this.idbusinessopportunitybrought = idbusinessopportunitybrought;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public Set<Businessopportunitybroughtinvoice> getBusinessopportunitybroughtinvoices() {
		return this.businessopportunitybroughtinvoices;
	}

	public void setBusinessopportunitybroughtinvoices(Set<Businessopportunitybroughtinvoice> businessopportunitybroughtinvoices) {
		this.businessopportunitybroughtinvoices = businessopportunitybroughtinvoices;
	}

	public Set<Businessopportunitybroughtstatushistory> getBusinessopportunitybroughtstatushistories() {
		return this.businessopportunitybroughtstatushistories;
	}

	public void setBusinessopportunitybroughtstatushistories(Set<Businessopportunitybroughtstatushistory> businessopportunitybroughtstatushistories) {
		this.businessopportunitybroughtstatushistories = businessopportunitybroughtstatushistories;
	}

	public Businessopportunitybroughtstatushistory addBusinessopportunitybroughtstatushistory(Businessopportunitybroughtstatushistory businessopportunitybroughtstatushistory) {
		getBusinessopportunitybroughtstatushistories().add(businessopportunitybroughtstatushistory);
		businessopportunitybroughtstatushistory.setBusinessopportunitybrought(this);

		return businessopportunitybroughtstatushistory;
	}

	public Businessopportunitybroughtstatushistory removeBusinessopportunitybroughtstatushistory(Businessopportunitybroughtstatushistory businessopportunitybroughtstatushistory) {
		getBusinessopportunitybroughtstatushistories().remove(businessopportunitybroughtstatushistory);
		businessopportunitybroughtstatushistory.setBusinessopportunitybrought(null);

		return businessopportunitybroughtstatushistory;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setBusinessopportunitybrought(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setBusinessopportunitybrought(null);

		return customerinvoice;
	}

}