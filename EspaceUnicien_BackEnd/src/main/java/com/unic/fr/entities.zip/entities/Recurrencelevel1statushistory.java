package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the recurrencelevel1statushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel1statushistory.findAll", query="SELECT r FROM Recurrencelevel1statushistory r")
public class Recurrencelevel1statushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL1STATUSHISTORY_IDRECLEVEL1STATUSHISTORY_GENERATOR", sequenceName="GUF.RECURRENCELEVEL1STATUSHISTORY_IDRECLEVEL1STATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL1STATUSHISTORY_IDRECLEVEL1STATUSHISTORY_GENERATOR")
	private Integer idreclevel1statushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Recurrencelevel1
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel1")
	private Recurrencelevel1 recurrencelevel1;

	public Recurrencelevel1statushistory() {
	}

	public Integer getIdreclevel1statushistory() {
		return this.idreclevel1statushistory;
	}

	public void setIdreclevel1statushistory(Integer idreclevel1statushistory) {
		this.idreclevel1statushistory = idreclevel1statushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Recurrencelevel1 getRecurrencelevel1() {
		return this.recurrencelevel1;
	}

	public void setRecurrencelevel1(Recurrencelevel1 recurrencelevel1) {
		this.recurrencelevel1 = recurrencelevel1;
	}

}