package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the packpartner database table.
 * 
 */
@Entity
@NamedQuery(name="Packpartner.findAll", query="SELECT p FROM Packpartner p")
public class Packpartner implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PackpartnerPK id;

	private Boolean active;

	@Temporal(TemporalType.DATE)
	private Date datesubscription;

	private float discount;

	//bi-directional many-to-one association to Packinvoice
	@OneToMany(mappedBy="packpartner")
	private Set<Packinvoice> packinvoices;

	//bi-directional many-to-one association to Pack
	@ManyToOne
	@JoinColumn(name="idpack" ,insertable=false, updatable=false)
	private Pack pack;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartner" ,insertable=false, updatable=false)
	private Partner partner;

	public Packpartner() {
	}

	public PackpartnerPK getId() {
		return this.id;
	}

	public void setId(PackpartnerPK id) {
		this.id = id;
	}

	public Boolean getActive() {
		return this.active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Date getDatesubscription() {
		return this.datesubscription;
	}

	public void setDatesubscription(Date datesubscription) {
		this.datesubscription = datesubscription;
	}

	public float getDiscount() {
		return this.discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public Set<Packinvoice> getPackinvoices() {
		return this.packinvoices;
	}

	public void setPackinvoices(Set<Packinvoice> packinvoices) {
		this.packinvoices = packinvoices;
	}

	public Packinvoice addPackinvoice(Packinvoice packinvoice) {
		getPackinvoices().add(packinvoice);
		packinvoice.setPackpartner(this);

		return packinvoice;
	}

	public Packinvoice removePackinvoice(Packinvoice packinvoice) {
		getPackinvoices().remove(packinvoice);
		packinvoice.setPackpartner(null);

		return packinvoice;
	}

	public Pack getPack() {
		return this.pack;
	}

	public void setPack(Pack pack) {
		this.pack = pack;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

}