package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the bobinvoicestatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Bobinvoicestatushistory.findAll", query="SELECT b FROM Bobinvoicestatushistory b")
public class Bobinvoicestatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="BOBINVOICESTATUSHISTORY_IDBOBINVOICESTATUSHISTORY_GENERATOR", sequenceName="GUF.BOBINVOICESTATUSHISTORY_IDBOBINVOICESTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BOBINVOICESTATUSHISTORY_IDBOBINVOICESTATUSHISTORY_GENERATOR")
	private Integer idbobinvoicestatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Businessopportunitybroughtinvoice
	@ManyToOne
	@JoinColumn(name="idbobinvoice")
	private Businessopportunitybroughtinvoice businessopportunitybroughtinvoice;

	public Bobinvoicestatushistory() {
	}

	public Integer getIdbobinvoicestatushistory() {
		return this.idbobinvoicestatushistory;
	}

	public void setIdbobinvoicestatushistory(Integer idbobinvoicestatushistory) {
		this.idbobinvoicestatushistory = idbobinvoicestatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Businessopportunitybroughtinvoice getBusinessopportunitybroughtinvoice() {
		return this.businessopportunitybroughtinvoice;
	}

	public void setBusinessopportunitybroughtinvoice(Businessopportunitybroughtinvoice businessopportunitybroughtinvoice) {
		this.businessopportunitybroughtinvoice = businessopportunitybroughtinvoice;
	}

}