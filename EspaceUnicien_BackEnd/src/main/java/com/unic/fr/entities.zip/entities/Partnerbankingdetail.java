package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the partnerbankingdetails database table.
 * 
 */
@Entity
@Table(name="partnerbankingdetails")
@NamedQuery(name="Partnerbankingdetail.findAll", query="SELECT p FROM Partnerbankingdetail p")
public class Partnerbankingdetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNERBANKINGDETAILS_IDPARTNERBANKINGDETAILS_GENERATOR", sequenceName="GUF.PARTNERBANKINGDETAILS_IDPARTNERBANKINGDETAILS_SEQ" , allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNERBANKINGDETAILS_IDPARTNERBANKINGDETAILS_GENERATOR")
	private Integer idpartnerbankingdetails;

	private String accountnumber;

	private String bankingname;

	private String biccode;

	private String ibannumber;

	private byte[] rib;

	private String sortcode;

	//bi-directional many-to-one association to Partner
	@OneToMany(mappedBy="partnerbankingdetail")
	private Set<Partner> partners;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idbankingaddress")
	private Address address;

	public Partnerbankingdetail() {
	}

	public Integer getIdpartnerbankingdetails() {
		return this.idpartnerbankingdetails;
	}

	public void setIdpartnerbankingdetails(Integer idpartnerbankingdetails) {
		this.idpartnerbankingdetails = idpartnerbankingdetails;
	}

	public String getAccountnumber() {
		return this.accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getBankingname() {
		return this.bankingname;
	}

	public void setBankingname(String bankingname) {
		this.bankingname = bankingname;
	}

	public String getBiccode() {
		return this.biccode;
	}

	public void setBiccode(String biccode) {
		this.biccode = biccode;
	}

	public String getIbannumber() {
		return this.ibannumber;
	}

	public void setIbannumber(String ibannumber) {
		this.ibannumber = ibannumber;
	}

	public byte[] getRib() {
		return this.rib;
	}

	public void setRib(byte[] rib) {
		this.rib = rib;
	}

	public String getSortcode() {
		return this.sortcode;
	}

	public void setSortcode(String sortcode) {
		this.sortcode = sortcode;
	}

	public Set<Partner> getPartners() {
		return this.partners;
	}

	public void setPartners(Set<Partner> partners) {
		this.partners = partners;
	}

	public Partner addPartner(Partner partner) {
		getPartners().add(partner);
		partner.setPartnerbankingdetail(this);

		return partner;
	}

	public Partner removePartner(Partner partner) {
		getPartners().remove(partner);
		partner.setPartnerbankingdetail(null);

		return partner;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}