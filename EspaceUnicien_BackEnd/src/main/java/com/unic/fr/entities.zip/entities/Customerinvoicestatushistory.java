package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the customerinvoicestatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Customerinvoicestatushistory.findAll", query="SELECT c FROM Customerinvoicestatushistory c")
public class Customerinvoicestatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CUSTOMERINVOICESTATUSHISTORY_IDCUSTOMERINVOICESTATUSHISTORY_GENERATOR", sequenceName="GUF.CUSTOMERINVOICESTATUSHISTORY_IDCUSTOMERINVOICESTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CUSTOMERINVOICESTATUSHISTORY_IDCUSTOMERINVOICESTATUSHISTORY_GENERATOR")
	private Integer idcustomerinvoicestatushistory;

	private Timestamp datecreation;

	private String note;

	private String status;

	//bi-directional many-to-one association to Customerinvoice
	@ManyToOne
	@JoinColumn(name="idcustomerinvoice")
	private Customerinvoice customerinvoice;

	public Customerinvoicestatushistory() {
	}

	public Integer getIdcustomerinvoicestatushistory() {
		return this.idcustomerinvoicestatushistory;
	}

	public void setIdcustomerinvoicestatushistory(Integer idcustomerinvoicestatushistory) {
		this.idcustomerinvoicestatushistory = idcustomerinvoicestatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Customerinvoice getCustomerinvoice() {
		return this.customerinvoice;
	}

	public void setCustomerinvoice(Customerinvoice customerinvoice) {
		this.customerinvoice = customerinvoice;
	}

}