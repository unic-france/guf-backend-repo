package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the recurrencelevel4statushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel4statushistory.findAll", query="SELECT r FROM Recurrencelevel4statushistory r")
public class Recurrencelevel4statushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL4STATUSHISTORY_IDRECLEVEL4STATUSHISTORY_GENERATOR", sequenceName="GUF.RECURRENCELEVEL4STATUSHISTORY_IDRECLEVEL4STATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL4STATUSHISTORY_IDRECLEVEL4STATUSHISTORY_GENERATOR")
	private Integer idreclevel4statushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Recurrencelevel4
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel4")
	private Recurrencelevel4 recurrencelevel4;

	public Recurrencelevel4statushistory() {
	}

	public Integer getIdreclevel4statushistory() {
		return this.idreclevel4statushistory;
	}

	public void setIdreclevel4statushistory(Integer idreclevel4statushistory) {
		this.idreclevel4statushistory = idreclevel4statushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Recurrencelevel4 getRecurrencelevel4() {
		return this.recurrencelevel4;
	}

	public void setRecurrencelevel4(Recurrencelevel4 recurrencelevel4) {
		this.recurrencelevel4 = recurrencelevel4;
	}

}