package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the customercontact database table.
 * 
 */
@Entity
@NamedQuery(name="Customercontact.findAll", query="SELECT c FROM Customercontact c")
public class Customercontact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CUSTOMERCONTACT_IDCUSTOMERCONTACT_GENERATOR", sequenceName="GUF.CUSTOMERCONTACT_IDCUSTOMERCONTACT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CUSTOMERCONTACT_IDCUSTOMERCONTACT_GENERATOR")
	private Integer idcustomercontact;

	private String cuid;

	private String email;

	private String firstname;

	private String lastname;

	private String mobilephone;

	private String phonenumber;

	private String position;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idaddress")
	private Address address;

	//bi-directional many-to-many association to Assignment
	@ManyToMany
	@JoinTable(
		name="assignementcustomercontact"
		, joinColumns={
			@JoinColumn(name="idcustomercontact")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idassignment")
			}
		)
	private Set<Assignment> assignments;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="idcustomer")
	private Customer customer;

	public Customercontact() {
	}

	public Integer getIdcustomercontact() {
		return this.idcustomercontact;
	}

	public void setIdcustomercontact(Integer idcustomercontact) {
		this.idcustomercontact = idcustomercontact;
	}

	public String getCuid() {
		return this.cuid;
	}

	public void setCuid(String cuid) {
		this.cuid = cuid;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMobilephone() {
		return this.mobilephone;
	}

	public void setMobilephone(String mobilephone) {
		this.mobilephone = mobilephone;
	}

	public String getPhonenumber() {
		return this.phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getPosition() {
		return this.position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Set<Assignment> getAssignments() {
		return this.assignments;
	}

	public void setAssignments(Set<Assignment> assignments) {
		this.assignments = assignments;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}