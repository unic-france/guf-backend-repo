package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the creditnote database table.
 * 
 */
@Entity
@NamedQuery(name="Creditnote.findAll", query="SELECT c FROM Creditnote c")
public class Creditnote implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CREDITNOTE_IDCREDITNOTE_GENERATOR", sequenceName="GUF.CREDITNOTE_IDCREDITNOTE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CREDITNOTE_IDCREDITNOTE_GENERATOR")
	private Integer idcreditnote;

	private float amountwithouttax;

	private float amountwithtax;

	private String currency;

	private String status;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Customerinvoice
	@ManyToOne
	@JoinColumn(name="idcustomerinvoice")
	private Customerinvoice customerinvoice;

	public Creditnote() {
	}

	public Integer getIdcreditnote() {
		return this.idcreditnote;
	}

	public void setIdcreditnote(Integer idcreditnote) {
		this.idcreditnote = idcreditnote;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Customerinvoice getCustomerinvoice() {
		return this.customerinvoice;
	}

	public void setCustomerinvoice(Customerinvoice customerinvoice) {
		this.customerinvoice = customerinvoice;
	}

}