package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the network database table.
 * 
 */
@Entity
@NamedQuery(name="Network.findAll", query="SELECT n FROM Network n")
public class Network implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="NETWORK_IDNETWORK_GENERATOR", sequenceName="GUF.NETWORK_IDNETWORK_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="NETWORK_IDNETWORK_GENERATOR")
	private Integer idnetwork;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartnergodparentlevel1")
	private Partner partner1;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartnergodparentlevel2")
	private Partner partner2;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartnergodparentlevel3")
	private Partner partner3;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartnergodparentlevel4")
	private Partner partner4;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartnergodparentlevel5")
	private Partner partner5;

	//bi-directional many-to-one association to Partnernetwork
	@OneToMany(mappedBy="network")
	private Set<Partnernetwork> partnernetworks;

	public Network() {
	}

	public Integer getIdnetwork() {
		return this.idnetwork;
	}

	public void setIdnetwork(Integer idnetwork) {
		this.idnetwork = idnetwork;
	}

	public Partner getPartner1() {
		return this.partner1;
	}

	public void setPartner1(Partner partner1) {
		this.partner1 = partner1;
	}

	public Partner getPartner2() {
		return this.partner2;
	}

	public void setPartner2(Partner partner2) {
		this.partner2 = partner2;
	}

	public Partner getPartner3() {
		return this.partner3;
	}

	public void setPartner3(Partner partner3) {
		this.partner3 = partner3;
	}

	public Partner getPartner4() {
		return this.partner4;
	}

	public void setPartner4(Partner partner4) {
		this.partner4 = partner4;
	}

	public Partner getPartner5() {
		return this.partner5;
	}

	public void setPartner5(Partner partner5) {
		this.partner5 = partner5;
	}

	public Set<Partnernetwork> getPartnernetworks() {
		return this.partnernetworks;
	}

	public void setPartnernetworks(Set<Partnernetwork> partnernetworks) {
		this.partnernetworks = partnernetworks;
	}

	public Partnernetwork addPartnernetwork(Partnernetwork partnernetwork) {
		getPartnernetworks().add(partnernetwork);
		partnernetwork.setNetwork(this);

		return partnernetwork;
	}

	public Partnernetwork removePartnernetwork(Partnernetwork partnernetwork) {
		getPartnernetworks().remove(partnernetwork);
		partnernetwork.setNetwork(null);

		return partnernetwork;
	}

}