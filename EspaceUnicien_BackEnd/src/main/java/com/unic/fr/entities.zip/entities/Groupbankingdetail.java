package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the groupbankingdetails database table.
 * 
 */
@Entity
@Table(name="groupbankingdetails")
@NamedQuery(name="Groupbankingdetail.findAll", query="SELECT g FROM Groupbankingdetail g")
public class Groupbankingdetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPBANKINGDETAILS_IDGROUPBANKINGDETAILS_GENERATOR", sequenceName="GUF.GROUPBANKINGDETAILS_IDGROUPBANKINGDETAILS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPBANKINGDETAILS_IDGROUPBANKINGDETAILS_GENERATOR")
	private Integer idgroupbankingdetails;

	private String accountnumber;

	private String bankingname;

	private String biccode;

	private String ibannumber;

	private String sortcode;

	//bi-directional many-to-one association to Groupcompany
	@OneToMany(mappedBy="groupbankingdetail")
	private Set<Groupcompany> groupcompanies;

	public Groupbankingdetail() {
	}

	public Integer getIdgroupbankingdetails() {
		return this.idgroupbankingdetails;
	}

	public void setIdgroupbankingdetails(Integer idgroupbankingdetails) {
		this.idgroupbankingdetails = idgroupbankingdetails;
	}

	public String getAccountnumber() {
		return this.accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getBankingname() {
		return this.bankingname;
	}

	public void setBankingname(String bankingname) {
		this.bankingname = bankingname;
	}

	public String getBiccode() {
		return this.biccode;
	}

	public void setBiccode(String biccode) {
		this.biccode = biccode;
	}

	public String getIbannumber() {
		return this.ibannumber;
	}

	public void setIbannumber(String ibannumber) {
		this.ibannumber = ibannumber;
	}

	public String getSortcode() {
		return this.sortcode;
	}

	public void setSortcode(String sortcode) {
		this.sortcode = sortcode;
	}

	public Set<Groupcompany> getGroupcompanies() {
		return this.groupcompanies;
	}

	public void setGroupcompanies(Set<Groupcompany> groupcompanies) {
		this.groupcompanies = groupcompanies;
	}

	public Groupcompany addGroupcompany(Groupcompany groupcompany) {
		getGroupcompanies().add(groupcompany);
		groupcompany.setGroupbankingdetail(this);

		return groupcompany;
	}

	public Groupcompany removeGroupcompany(Groupcompany groupcompany) {
		getGroupcompanies().remove(groupcompany);
		groupcompany.setGroupbankingdetail(null);

		return groupcompany;
	}

}