package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the recurrenceinvoicestatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrenceinvoicestatushistory.findAll", query="SELECT r FROM Recurrenceinvoicestatushistory r")
public class Recurrenceinvoicestatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCEINVOICESTATUSHISTORY_IDRECINVOICESTATUSHISTORY_GENERATOR", sequenceName="GUF.RECURRENCEINVOICESTATUSHISTORY_IDRECINVOICESTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCEINVOICESTATUSHISTORY_IDRECINVOICESTATUSHISTORY_GENERATOR")
	private Integer idrecinvoicestatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Recurrenceinvoice
	@ManyToOne
	@JoinColumn(name="idreccurenceinvoice")
	private Recurrenceinvoice recurrenceinvoice;

	public Recurrenceinvoicestatushistory() {
	}

	public Integer getIdrecinvoicestatushistory() {
		return this.idrecinvoicestatushistory;
	}

	public void setIdrecinvoicestatushistory(Integer idrecinvoicestatushistory) {
		this.idrecinvoicestatushistory = idrecinvoicestatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Recurrenceinvoice getRecurrenceinvoice() {
		return this.recurrenceinvoice;
	}

	public void setRecurrenceinvoice(Recurrenceinvoice recurrenceinvoice) {
		this.recurrenceinvoice = recurrenceinvoice;
	}

}