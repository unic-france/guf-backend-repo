package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the qualificationpartner database table.
 * 
 */
@Embeddable
public class QualificationpartnerPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false)
	private Integer idpartner;

	@Column(insertable=false, updatable=false)
	private Integer idqualification;

	public QualificationpartnerPK() {
	}
	public Integer getIdpartner() {
		return this.idpartner;
	}
	public void setIdpartner(Integer idpartner) {
		this.idpartner = idpartner;
	}
	public Integer getIdqualification() {
		return this.idqualification;
	}
	public void setIdqualification(Integer idqualification) {
		this.idqualification = idqualification;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof QualificationpartnerPK)) {
			return false;
		}
		QualificationpartnerPK castOther = (QualificationpartnerPK)other;
		return 
			this.idpartner.equals(castOther.idpartner)
			&& this.idqualification.equals(castOther.idqualification);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.idpartner.hashCode();
		hash = hash * prime + this.idqualification.hashCode();
		
		return hash;
	}
}