package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the partnerprofile database table.
 * 
 */
@Entity
@NamedQuery(name="Partnerprofile.findAll", query="SELECT p FROM Partnerprofile p")
public class Partnerprofile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNERPROFILE_IDPARTNERPROFILE_GENERATOR", sequenceName="GUF.PARTNERPROFILE_IDPARTNERPROFILE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNERPROFILE_IDPARTNERPROFILE_GENERATOR")
	private Integer idpartnerprofile;

	private byte[] cv;

	@Temporal(TemporalType.DATE)
	private Date dateofbirth;

	private String firstname;

	private String linkedinurl;

	private String name;

	private byte[] picture;

	private String summary;

	private String title;

	//bi-directional many-to-one association to Partner
	@OneToMany(mappedBy="partnerprofile")
	private Set<Partner> partners;

	//bi-directional many-to-one association to Partnercontact
	@ManyToOne
	@JoinColumn(name="idpartnercontact")
	private Partnercontact partnercontact;

	//bi-directional many-to-one association to Partnerpreference
	@ManyToOne
	@JoinColumn(name="idpartnerpreference")
	private Partnerpreference partnerpreference;

	//bi-directional many-to-one association to Skill
	@OneToMany(mappedBy="partnerprofile")
	private Set<Skill> skills;

	public Partnerprofile() {
	}

	public Integer getIdpartnerprofile() {
		return this.idpartnerprofile;
	}

	public void setIdpartnerprofile(Integer idpartnerprofile) {
		this.idpartnerprofile = idpartnerprofile;
	}

	public byte[] getCv() {
		return this.cv;
	}

	public void setCv(byte[] cv) {
		this.cv = cv;
	}

	public Date getDateofbirth() {
		return this.dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLinkedinurl() {
		return this.linkedinurl;
	}

	public void setLinkedinurl(String linkedinurl) {
		this.linkedinurl = linkedinurl;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte[] getPicture() {
		return this.picture;
	}

	public void setPicture(byte[] picture) {
		this.picture = picture;
	}

	public String getSummary() {
		return this.summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Set<Partner> getPartners() {
		return this.partners;
	}

	public void setPartners(Set<Partner> partners) {
		this.partners = partners;
	}

	public Partner addPartner(Partner partner) {
		getPartners().add(partner);
		partner.setPartnerprofile(this);

		return partner;
	}

	public Partner removePartner(Partner partner) {
		getPartners().remove(partner);
		partner.setPartnerprofile(null);

		return partner;
	}

	public Partnercontact getPartnercontact() {
		return this.partnercontact;
	}

	public void setPartnercontact(Partnercontact partnercontact) {
		this.partnercontact = partnercontact;
	}

	public Partnerpreference getPartnerpreference() {
		return this.partnerpreference;
	}

	public void setPartnerpreference(Partnerpreference partnerpreference) {
		this.partnerpreference = partnerpreference;
	}

	public Set<Skill> getSkills() {
		return this.skills;
	}

	public void setSkills(Set<Skill> skills) {
		this.skills = skills;
	}

	public Skill addSkill(Skill skill) {
		getSkills().add(skill);
		skill.setPartnerprofile(this);

		return skill;
	}

	public Skill removeSkill(Skill skill) {
		getSkills().remove(skill);
		skill.setPartnerprofile(null);

		return skill;
	}

}