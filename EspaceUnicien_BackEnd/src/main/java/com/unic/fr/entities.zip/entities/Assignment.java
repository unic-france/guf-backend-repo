package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the assignment database table.
 * 
 */
@Entity
@NamedQuery(name="Assignment.findAll", query="SELECT a FROM Assignment a")
public class Assignment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ASSIGNMENT_IDASSIGNMENT_GENERATOR", sequenceName="GUF.ASSIGNMENT_IDASSIGNMENT_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ASSIGNMENT_IDASSIGNMENT_GENERATOR")
	private Integer idassignment;

	private Boolean activityreportcustomercompulsory;

	private String assignmentreferencenumber;

	private Boolean businessopportunitybroughtactive;

	private String countrycode;

	private String currency;

	@Temporal(TemporalType.DATE)
	private Date dateofbeginning;

	@Temporal(TemporalType.DATE)
	private Date dateofend;

	private float daypricewithouttax;

	private String descriptionfull;

	private String descriptionshort;

	private String functionalscope;

	private Boolean portage;

	private String position;

	private Boolean tacitrenewal;

	//bi-directional many-to-one association to Address
	@ManyToOne
	@JoinColumn(name="idaddress")
	private Address address;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="idcustomerend")
	private Customer customer1;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="idcustomerinvoiced")
	private Customer customer2;

	//bi-directional many-to-one association to Customerinvoicedetail
	@ManyToOne
	@JoinColumn(name="idcustomerinvoicedetails")
	private Customerinvoicedetail customerinvoicedetail;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartner")
	private Partner partner1;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartnerbusinessopportunitybrought")
	private Partner partner2;

	//bi-directional many-to-one association to Assignmentstatushistory
	@OneToMany(mappedBy="assignment")
	private Set<Assignmentstatushistory> assignmentstatushistories;

	//bi-directional many-to-many association to Contract
	@ManyToMany(mappedBy="assignments")
	private Set<Contract> contracts;

	//bi-directional many-to-many association to Customercontact
	@ManyToMany(mappedBy="assignments")
	private Set<Customercontact> customercontacts;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="assignment")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-many association to Groupstaffmember
	@ManyToMany(mappedBy="assignments")
	private Set<Groupstaffmember> groupstaffmembers;

	//bi-directional many-to-one association to Missionorder
	@OneToMany(mappedBy="assignment")
	private Set<Missionorder> missionorders;

	//bi-directional many-to-one association to Purchaseorder
	@OneToMany(mappedBy="assignment")
	private Set<Purchaseorder> purchaseorders;

	public Assignment() {
	}

	public Integer getIdassignment() {
		return this.idassignment;
	}

	public void setIdassignment(Integer idassignment) {
		this.idassignment = idassignment;
	}

	public Boolean getActivityreportcustomercompulsory() {
		return this.activityreportcustomercompulsory;
	}

	public void setActivityreportcustomercompulsory(Boolean activityreportcustomercompulsory) {
		this.activityreportcustomercompulsory = activityreportcustomercompulsory;
	}

	public String getAssignmentreferencenumber() {
		return this.assignmentreferencenumber;
	}

	public void setAssignmentreferencenumber(String assignmentreferencenumber) {
		this.assignmentreferencenumber = assignmentreferencenumber;
	}

	public Boolean getBusinessopportunitybroughtactive() {
		return this.businessopportunitybroughtactive;
	}

	public void setBusinessopportunitybroughtactive(Boolean businessopportunitybroughtactive) {
		this.businessopportunitybroughtactive = businessopportunitybroughtactive;
	}

	public String getCountrycode() {
		return this.countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getDateofbeginning() {
		return this.dateofbeginning;
	}

	public void setDateofbeginning(Date dateofbeginning) {
		this.dateofbeginning = dateofbeginning;
	}

	public Date getDateofend() {
		return this.dateofend;
	}

	public void setDateofend(Date dateofend) {
		this.dateofend = dateofend;
	}

	public float getDaypricewithouttax() {
		return this.daypricewithouttax;
	}

	public void setDaypricewithouttax(float daypricewithouttax) {
		this.daypricewithouttax = daypricewithouttax;
	}

	public String getDescriptionfull() {
		return this.descriptionfull;
	}

	public void setDescriptionfull(String descriptionfull) {
		this.descriptionfull = descriptionfull;
	}

	public String getDescriptionshort() {
		return this.descriptionshort;
	}

	public void setDescriptionshort(String descriptionshort) {
		this.descriptionshort = descriptionshort;
	}

	public String getFunctionalscope() {
		return this.functionalscope;
	}

	public void setFunctionalscope(String functionalscope) {
		this.functionalscope = functionalscope;
	}

	public Boolean getPortage() {
		return this.portage;
	}

	public void setPortage(Boolean portage) {
		this.portage = portage;
	}

	public String getPosition() {
		return this.position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public Boolean getTacitrenewal() {
		return this.tacitrenewal;
	}

	public void setTacitrenewal(Boolean tacitrenewal) {
		this.tacitrenewal = tacitrenewal;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Customer getCustomer1() {
		return this.customer1;
	}

	public void setCustomer1(Customer customer1) {
		this.customer1 = customer1;
	}

	public Customer getCustomer2() {
		return this.customer2;
	}

	public void setCustomer2(Customer customer2) {
		this.customer2 = customer2;
	}

	public Customerinvoicedetail getCustomerinvoicedetail() {
		return this.customerinvoicedetail;
	}

	public void setCustomerinvoicedetail(Customerinvoicedetail customerinvoicedetail) {
		this.customerinvoicedetail = customerinvoicedetail;
	}

	public Partner getPartner1() {
		return this.partner1;
	}

	public void setPartner1(Partner partner1) {
		this.partner1 = partner1;
	}

	public Partner getPartner2() {
		return this.partner2;
	}

	public void setPartner2(Partner partner2) {
		this.partner2 = partner2;
	}

	public Set<Assignmentstatushistory> getAssignmentstatushistories() {
		return this.assignmentstatushistories;
	}

	public void setAssignmentstatushistories(Set<Assignmentstatushistory> assignmentstatushistories) {
		this.assignmentstatushistories = assignmentstatushistories;
	}

	public Assignmentstatushistory addAssignmentstatushistory(Assignmentstatushistory assignmentstatushistory) {
		getAssignmentstatushistories().add(assignmentstatushistory);
		assignmentstatushistory.setAssignment(this);

		return assignmentstatushistory;
	}

	public Assignmentstatushistory removeAssignmentstatushistory(Assignmentstatushistory assignmentstatushistory) {
		getAssignmentstatushistories().remove(assignmentstatushistory);
		assignmentstatushistory.setAssignment(null);

		return assignmentstatushistory;
	}

	public Set<Contract> getContracts() {
		return this.contracts;
	}

	public void setContracts(Set<Contract> contracts) {
		this.contracts = contracts;
	}

	public Set<Customercontact> getCustomercontacts() {
		return this.customercontacts;
	}

	public void setCustomercontacts(Set<Customercontact> customercontacts) {
		this.customercontacts = customercontacts;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setAssignment(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setAssignment(null);

		return customerinvoice;
	}

	public Set<Groupstaffmember> getGroupstaffmembers() {
		return this.groupstaffmembers;
	}

	public void setGroupstaffmembers(Set<Groupstaffmember> groupstaffmembers) {
		this.groupstaffmembers = groupstaffmembers;
	}

	public Set<Missionorder> getMissionorders() {
		return this.missionorders;
	}

	public void setMissionorders(Set<Missionorder> missionorders) {
		this.missionorders = missionorders;
	}

	public Missionorder addMissionorder(Missionorder missionorder) {
		getMissionorders().add(missionorder);
		missionorder.setAssignment(this);

		return missionorder;
	}

	public Missionorder removeMissionorder(Missionorder missionorder) {
		getMissionorders().remove(missionorder);
		missionorder.setAssignment(null);

		return missionorder;
	}

	public Set<Purchaseorder> getPurchaseorders() {
		return this.purchaseorders;
	}

	public void setPurchaseorders(Set<Purchaseorder> purchaseorders) {
		this.purchaseorders = purchaseorders;
	}

	public Purchaseorder addPurchaseorder(Purchaseorder purchaseorder) {
		getPurchaseorders().add(purchaseorder);
		purchaseorder.setAssignment(this);

		return purchaseorder;
	}

	public Purchaseorder removePurchaseorder(Purchaseorder purchaseorder) {
		getPurchaseorders().remove(purchaseorder);
		purchaseorder.setAssignment(null);

		return purchaseorder;
	}

}