package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the skill database table.
 * 
 */
@Entity
@NamedQuery(name="Skill.findAll", query="SELECT s FROM Skill s")
public class Skill implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SKILL_IDSKILL_GENERATOR", sequenceName="GUF.SKILL_IDSKILL_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SKILL_IDSKILL_GENERATOR")
	private Integer idskill;

	private Integer level;

	private String skill;

	//bi-directional many-to-one association to Partnerprofile
	@ManyToOne
	@JoinColumn(name="idpartnerprofile")
	private Partnerprofile partnerprofile;

	public Skill() {
	}

	public Integer getIdskill() {
		return this.idskill;
	}

	public void setIdskill(Integer idskill) {
		this.idskill = idskill;
	}

	public Integer getLevel() {
		return this.level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public String getSkill() {
		return this.skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public Partnerprofile getPartnerprofile() {
		return this.partnerprofile;
	}

	public void setPartnerprofile(Partnerprofile partnerprofile) {
		this.partnerprofile = partnerprofile;
	}

}