package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the businessopportunitybroughtstatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Businessopportunitybroughtstatushistory.findAll", query="SELECT b FROM Businessopportunitybroughtstatushistory b")
public class Businessopportunitybroughtstatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="BUSINESSOPPORTUNITYBROUGHTSTATUSHISTORY_IDBOBSTATUSHISTORY_GENERATOR", sequenceName="GUF.BUSINESSOPPORTUNITYBROUGHTSTATUSHISTORY_IDBOBSTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BUSINESSOPPORTUNITYBROUGHTSTATUSHISTORY_IDBOBSTATUSHISTORY_GENERATOR")
	private Integer idbobstatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Businessopportunitybrought
	@ManyToOne
	@JoinColumn(name="idbusinessopportunitybrought")
	private Businessopportunitybrought businessopportunitybrought;

	public Businessopportunitybroughtstatushistory() {
	}

	public Integer getIdbobstatushistory() {
		return this.idbobstatushistory;
	}

	public void setIdbobstatushistory(Integer idbobstatushistory) {
		this.idbobstatushistory = idbobstatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Businessopportunitybrought getBusinessopportunitybrought() {
		return this.businessopportunitybrought;
	}

	public void setBusinessopportunitybrought(Businessopportunitybrought businessopportunitybrought) {
		this.businessopportunitybrought = businessopportunitybrought;
	}

}