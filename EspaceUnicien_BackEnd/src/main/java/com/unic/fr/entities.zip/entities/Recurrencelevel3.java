package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the recurrencelevel3 database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel3.findAll", query="SELECT r FROM Recurrencelevel3 r")
public class Recurrencelevel3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL3_IDRECURRENCELEVEL3_GENERATOR", sequenceName="GUF.RECURRENCELEVEL3_IDRECURRENCELEVEL3_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL3_IDRECURRENCELEVEL3_GENERATOR")
	private Integer idrecurrencelevel3;

	private float amountwithouttax;

	private float amountwithtax;

	private Boolean capitalized;

	private String currency;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="recurrencelevel3")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Partnernetwork
	@ManyToOne
	@JoinColumn(name="idpartnernetwork")
	private Partnernetwork partnernetwork;

	//bi-directional many-to-many association to Recurrenceinvoice
	@ManyToMany
	@JoinTable(
		name="recurrenceinvoicereccurencelevel3"
		, joinColumns={
			@JoinColumn(name="idrecurrencelevel3")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idreccurenceinvoice")
			}
		)
	private Set<Recurrenceinvoice> recurrenceinvoices;

	//bi-directional many-to-one association to Recurrencelevel3statushistory
	@OneToMany(mappedBy="recurrencelevel3")
	private Set<Recurrencelevel3statushistory> recurrencelevel3statushistories;

	public Recurrencelevel3() {
	}

	public Integer getIdrecurrencelevel3() {
		return this.idrecurrencelevel3;
	}

	public void setIdrecurrencelevel3(Integer idrecurrencelevel3) {
		this.idrecurrencelevel3 = idrecurrencelevel3;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public Boolean getCapitalized() {
		return this.capitalized;
	}

	public void setCapitalized(Boolean capitalized) {
		this.capitalized = capitalized;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setRecurrencelevel3(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setRecurrencelevel3(null);

		return customerinvoice;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Partnernetwork getPartnernetwork() {
		return this.partnernetwork;
	}

	public void setPartnernetwork(Partnernetwork partnernetwork) {
		this.partnernetwork = partnernetwork;
	}

	public Set<Recurrenceinvoice> getRecurrenceinvoices() {
		return this.recurrenceinvoices;
	}

	public void setRecurrenceinvoices(Set<Recurrenceinvoice> recurrenceinvoices) {
		this.recurrenceinvoices = recurrenceinvoices;
	}

	public Set<Recurrencelevel3statushistory> getRecurrencelevel3statushistories() {
		return this.recurrencelevel3statushistories;
	}

	public void setRecurrencelevel3statushistories(Set<Recurrencelevel3statushistory> recurrencelevel3statushistories) {
		this.recurrencelevel3statushistories = recurrencelevel3statushistories;
	}

	public Recurrencelevel3statushistory addRecurrencelevel3statushistory(Recurrencelevel3statushistory recurrencelevel3statushistory) {
		getRecurrencelevel3statushistories().add(recurrencelevel3statushistory);
		recurrencelevel3statushistory.setRecurrencelevel3(this);

		return recurrencelevel3statushistory;
	}

	public Recurrencelevel3statushistory removeRecurrencelevel3statushistory(Recurrencelevel3statushistory recurrencelevel3statushistory) {
		getRecurrencelevel3statushistories().remove(recurrencelevel3statushistory);
		recurrencelevel3statushistory.setRecurrencelevel3(null);

		return recurrencelevel3statushistory;
	}

}