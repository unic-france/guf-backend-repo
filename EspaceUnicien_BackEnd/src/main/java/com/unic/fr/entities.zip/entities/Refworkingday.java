package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the refworkingdays database table.
 * 
 */
@Entity
@Table(name="refworkingdays")
@NamedQuery(name="Refworkingday.findAll", query="SELECT r FROM Refworkingday r")
public class Refworkingday implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="REFWORKINGDAYS_IDREFWORKINGDAYS_GENERATOR", sequenceName="GUF.REFWORKINGDAYS_IDREFWORKINGDAYS_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="REFWORKINGDAYS_IDREFWORKINGDAYS_GENERATOR")
	private Integer idrefworkingdays;

	private String month;

	private Integer workingdays;

	private String year;

	public Refworkingday() {
	}

	public Integer getIdrefworkingdays() {
		return this.idrefworkingdays;
	}

	public void setIdrefworkingdays(Integer idrefworkingdays) {
		this.idrefworkingdays = idrefworkingdays;
	}

	public String getMonth() {
		return this.month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Integer getWorkingdays() {
		return this.workingdays;
	}

	public void setWorkingdays(Integer workingdays) {
		this.workingdays = workingdays;
	}

	public String getYear() {
		return this.year;
	}

	public void setYear(String year) {
		this.year = year;
	}

}