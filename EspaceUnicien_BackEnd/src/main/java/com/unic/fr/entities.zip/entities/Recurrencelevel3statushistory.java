package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the recurrencelevel3statushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel3statushistory.findAll", query="SELECT r FROM Recurrencelevel3statushistory r")
public class Recurrencelevel3statushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL3STATUSHISTORY_IDRECLEVEL3STATUSHISTORY_GENERATOR", sequenceName="GUF.RECURRENCELEVEL3STATUSHISTORY_IDRECLEVEL3STATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL3STATUSHISTORY_IDRECLEVEL3STATUSHISTORY_GENERATOR")
	private Integer idreclevel3statushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Recurrencelevel3
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel3")
	private Recurrencelevel3 recurrencelevel3;

	public Recurrencelevel3statushistory() {
	}

	public Integer getIdreclevel3statushistory() {
		return this.idreclevel3statushistory;
	}

	public void setIdreclevel3statushistory(Integer idreclevel3statushistory) {
		this.idreclevel3statushistory = idreclevel3statushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Recurrencelevel3 getRecurrencelevel3() {
		return this.recurrencelevel3;
	}

	public void setRecurrencelevel3(Recurrencelevel3 recurrencelevel3) {
		this.recurrencelevel3 = recurrencelevel3;
	}

}