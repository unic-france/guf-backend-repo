package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the connexionhistorygroupstaffmember database table.
 * 
 */
@Entity
@NamedQuery(name="Connexionhistorygroupstaffmember.findAll", query="SELECT c FROM Connexionhistorygroupstaffmember c")
public class Connexionhistorygroupstaffmember implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CONNEXIONHISTORYGROUPSTAFFMEMBER_IDCONNEXIONHISTORYGSM_GENERATOR", sequenceName="GUF.CONNEXIONHISTORYGROUPSTAFFMEMBER_IDCONNEXIONHISTORYGSM_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CONNEXIONHISTORYGROUPSTAFFMEMBER_IDCONNEXIONHISTORYGSM_GENERATOR")
	private Integer idconnexionhistorygsm;

	private Timestamp dateconnexion;

	//bi-directional many-to-one association to Groupstaffmember
	@ManyToOne
	@JoinColumn(name="idgroupstaffmember")
	private Groupstaffmember groupstaffmember;

	public Connexionhistorygroupstaffmember() {
	}

	public Integer getIdconnexionhistorygsm() {
		return this.idconnexionhistorygsm;
	}

	public void setIdconnexionhistorygsm(Integer idconnexionhistorygsm) {
		this.idconnexionhistorygsm = idconnexionhistorygsm;
	}

	public Timestamp getDateconnexion() {
		return this.dateconnexion;
	}

	public void setDateconnexion(Timestamp dateconnexion) {
		this.dateconnexion = dateconnexion;
	}

	public Groupstaffmember getGroupstaffmember() {
		return this.groupstaffmember;
	}

	public void setGroupstaffmember(Groupstaffmember groupstaffmember) {
		this.groupstaffmember = groupstaffmember;
	}

}