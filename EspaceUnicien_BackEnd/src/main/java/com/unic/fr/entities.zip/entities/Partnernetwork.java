package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the partnernetwork database table.
 * 
 */
@Entity
@NamedQuery(name="Partnernetwork.findAll", query="SELECT p FROM Partnernetwork p")
public class Partnernetwork implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNERNETWORK_IDPARTNERNETWORK_GENERATOR", sequenceName="GUF.PARTNERNETWORK_IDPARTNERNETWORK_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNERNETWORK_IDPARTNERNETWORK_GENERATOR")
	private Integer idpartnernetwork;

	private Boolean current;

	private Timestamp date;

	//bi-directional many-to-one association to Network
	@ManyToOne
	@JoinColumn(name="idnetwork")
	private Network network;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartner")
	private Partner partner;

	//bi-directional many-to-one association to Recurrencegroup
	@OneToMany(mappedBy="partnernetwork")
	private Set<Recurrencegroup> recurrencegroups;

	//bi-directional many-to-one association to Recurrencelevel1
	@OneToMany(mappedBy="partnernetwork")
	private Set<Recurrencelevel1> recurrencelevel1s;

	//bi-directional many-to-one association to Recurrencelevel2
	@OneToMany(mappedBy="partnernetwork")
	private Set<Recurrencelevel2> recurrencelevel2s;

	//bi-directional many-to-one association to Recurrencelevel3
	@OneToMany(mappedBy="partnernetwork")
	private Set<Recurrencelevel3> recurrencelevel3s;

	//bi-directional many-to-one association to Recurrencelevel4
	@OneToMany(mappedBy="partnernetwork")
	private Set<Recurrencelevel4> recurrencelevel4s;

	//bi-directional many-to-one association to Recurrencelevel5
	@OneToMany(mappedBy="partnernetwork")
	private Set<Recurrencelevel5> recurrencelevel5s;

	public Partnernetwork() {
	}

	public Integer getIdpartnernetwork() {
		return this.idpartnernetwork;
	}

	public void setIdpartnernetwork(Integer idpartnernetwork) {
		this.idpartnernetwork = idpartnernetwork;
	}

	public Boolean getCurrent() {
		return this.current;
	}

	public void setCurrent(Boolean current) {
		this.current = current;
	}

	public Timestamp getDate() {
		return this.date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public Network getNetwork() {
		return this.network;
	}

	public void setNetwork(Network network) {
		this.network = network;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public Set<Recurrencegroup> getRecurrencegroups() {
		return this.recurrencegroups;
	}

	public void setRecurrencegroups(Set<Recurrencegroup> recurrencegroups) {
		this.recurrencegroups = recurrencegroups;
	}

	public Recurrencegroup addRecurrencegroup(Recurrencegroup recurrencegroup) {
		getRecurrencegroups().add(recurrencegroup);
		recurrencegroup.setPartnernetwork(this);

		return recurrencegroup;
	}

	public Recurrencegroup removeRecurrencegroup(Recurrencegroup recurrencegroup) {
		getRecurrencegroups().remove(recurrencegroup);
		recurrencegroup.setPartnernetwork(null);

		return recurrencegroup;
	}

	public Set<Recurrencelevel1> getRecurrencelevel1s() {
		return this.recurrencelevel1s;
	}

	public void setRecurrencelevel1s(Set<Recurrencelevel1> recurrencelevel1s) {
		this.recurrencelevel1s = recurrencelevel1s;
	}

	public Recurrencelevel1 addRecurrencelevel1(Recurrencelevel1 recurrencelevel1) {
		getRecurrencelevel1s().add(recurrencelevel1);
		recurrencelevel1.setPartnernetwork(this);

		return recurrencelevel1;
	}

	public Recurrencelevel1 removeRecurrencelevel1(Recurrencelevel1 recurrencelevel1) {
		getRecurrencelevel1s().remove(recurrencelevel1);
		recurrencelevel1.setPartnernetwork(null);

		return recurrencelevel1;
	}

	public Set<Recurrencelevel2> getRecurrencelevel2s() {
		return this.recurrencelevel2s;
	}

	public void setRecurrencelevel2s(Set<Recurrencelevel2> recurrencelevel2s) {
		this.recurrencelevel2s = recurrencelevel2s;
	}

	public Recurrencelevel2 addRecurrencelevel2(Recurrencelevel2 recurrencelevel2) {
		getRecurrencelevel2s().add(recurrencelevel2);
		recurrencelevel2.setPartnernetwork(this);

		return recurrencelevel2;
	}

	public Recurrencelevel2 removeRecurrencelevel2(Recurrencelevel2 recurrencelevel2) {
		getRecurrencelevel2s().remove(recurrencelevel2);
		recurrencelevel2.setPartnernetwork(null);

		return recurrencelevel2;
	}

	public Set<Recurrencelevel3> getRecurrencelevel3s() {
		return this.recurrencelevel3s;
	}

	public void setRecurrencelevel3s(Set<Recurrencelevel3> recurrencelevel3s) {
		this.recurrencelevel3s = recurrencelevel3s;
	}

	public Recurrencelevel3 addRecurrencelevel3(Recurrencelevel3 recurrencelevel3) {
		getRecurrencelevel3s().add(recurrencelevel3);
		recurrencelevel3.setPartnernetwork(this);

		return recurrencelevel3;
	}

	public Recurrencelevel3 removeRecurrencelevel3(Recurrencelevel3 recurrencelevel3) {
		getRecurrencelevel3s().remove(recurrencelevel3);
		recurrencelevel3.setPartnernetwork(null);

		return recurrencelevel3;
	}

	public Set<Recurrencelevel4> getRecurrencelevel4s() {
		return this.recurrencelevel4s;
	}

	public void setRecurrencelevel4s(Set<Recurrencelevel4> recurrencelevel4s) {
		this.recurrencelevel4s = recurrencelevel4s;
	}

	public Recurrencelevel4 addRecurrencelevel4(Recurrencelevel4 recurrencelevel4) {
		getRecurrencelevel4s().add(recurrencelevel4);
		recurrencelevel4.setPartnernetwork(this);

		return recurrencelevel4;
	}

	public Recurrencelevel4 removeRecurrencelevel4(Recurrencelevel4 recurrencelevel4) {
		getRecurrencelevel4s().remove(recurrencelevel4);
		recurrencelevel4.setPartnernetwork(null);

		return recurrencelevel4;
	}

	public Set<Recurrencelevel5> getRecurrencelevel5s() {
		return this.recurrencelevel5s;
	}

	public void setRecurrencelevel5s(Set<Recurrencelevel5> recurrencelevel5s) {
		this.recurrencelevel5s = recurrencelevel5s;
	}

	public Recurrencelevel5 addRecurrencelevel5(Recurrencelevel5 recurrencelevel5) {
		getRecurrencelevel5s().add(recurrencelevel5);
		recurrencelevel5.setPartnernetwork(this);

		return recurrencelevel5;
	}

	public Recurrencelevel5 removeRecurrencelevel5(Recurrencelevel5 recurrencelevel5) {
		getRecurrencelevel5s().remove(recurrencelevel5);
		recurrencelevel5.setPartnernetwork(null);

		return recurrencelevel5;
	}

}