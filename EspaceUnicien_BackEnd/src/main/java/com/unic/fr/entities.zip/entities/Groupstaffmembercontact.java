package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the groupstaffmembercontact database table.
 * 
 */
@Entity
@NamedQuery(name="Groupstaffmembercontact.findAll", query="SELECT g FROM Groupstaffmembercontact g")
public class Groupstaffmembercontact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPSTAFFMEMBERCONTACT_IDGROUPSTAFFMEMBERCONTACT_GENERATOR", sequenceName="GUF.GROUPSTAFFMEMBERCONTACT_IDGROUPSTAFFMEMBERCONTACT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPSTAFFMEMBERCONTACT_IDGROUPSTAFFMEMBERCONTACT_GENERATOR")
	private Integer idgroupstaffmembercontact;

	private String emailgroup;

	private String mobilephonenumber;

	private String phonenumber;

	//bi-directional many-to-one association to Groupstaffmemberprofile
	@OneToMany(mappedBy="groupstaffmembercontact")
	private Set<Groupstaffmemberprofile> groupstaffmemberprofiles;

	public Groupstaffmembercontact() {
	}

	public Integer getIdgroupstaffmembercontact() {
		return this.idgroupstaffmembercontact;
	}

	public void setIdgroupstaffmembercontact(Integer idgroupstaffmembercontact) {
		this.idgroupstaffmembercontact = idgroupstaffmembercontact;
	}

	public String getEmailgroup() {
		return this.emailgroup;
	}

	public void setEmailgroup(String emailgroup) {
		this.emailgroup = emailgroup;
	}

	public String getMobilephonenumber() {
		return this.mobilephonenumber;
	}

	public void setMobilephonenumber(String mobilephonenumber) {
		this.mobilephonenumber = mobilephonenumber;
	}

	public String getPhonenumber() {
		return this.phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Set<Groupstaffmemberprofile> getGroupstaffmemberprofiles() {
		return this.groupstaffmemberprofiles;
	}

	public void setGroupstaffmemberprofiles(Set<Groupstaffmemberprofile> groupstaffmemberprofiles) {
		this.groupstaffmemberprofiles = groupstaffmemberprofiles;
	}

	public Groupstaffmemberprofile addGroupstaffmemberprofile(Groupstaffmemberprofile groupstaffmemberprofile) {
		getGroupstaffmemberprofiles().add(groupstaffmemberprofile);
		groupstaffmemberprofile.setGroupstaffmembercontact(this);

		return groupstaffmemberprofile;
	}

	public Groupstaffmemberprofile removeGroupstaffmemberprofile(Groupstaffmemberprofile groupstaffmemberprofile) {
		getGroupstaffmemberprofiles().remove(groupstaffmemberprofile);
		groupstaffmemberprofile.setGroupstaffmembercontact(null);

		return groupstaffmemberprofile;
	}

}