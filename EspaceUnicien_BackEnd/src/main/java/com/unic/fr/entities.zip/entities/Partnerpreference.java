package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the partnerpreference database table.
 * 
 */
@Entity
@NamedQuery(name="Partnerpreference.findAll", query="SELECT p FROM Partnerpreference p")
public class Partnerpreference implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNERPREFERENCE_IDPARTNERPREFERENCE_GENERATOR", sequenceName="GUF.PARTNERPREFERENCE_IDPARTNERPREFERENCE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNERPREFERENCE_IDPARTNERPREFERENCE_GENERATOR")
	private Integer idpartnerpreference;

	private String language;

	private Boolean showfulllastnametorecruiter;

	private Boolean showfullmobilephonetorecruiter;

	private Boolean showmissionendsoon;

	private Boolean showonline;

	private Boolean showprofilesharedwithrecruiter;

	//bi-directional many-to-one association to Partnerprofile
	@OneToMany(mappedBy="partnerpreference")
	private Set<Partnerprofile> partnerprofiles;

	public Partnerpreference() {
	}

	public Integer getIdpartnerpreference() {
		return this.idpartnerpreference;
	}

	public void setIdpartnerpreference(Integer idpartnerpreference) {
		this.idpartnerpreference = idpartnerpreference;
	}

	public String getLanguage() {
		return this.language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Boolean getShowfulllastnametorecruiter() {
		return this.showfulllastnametorecruiter;
	}

	public void setShowfulllastnametorecruiter(Boolean showfulllastnametorecruiter) {
		this.showfulllastnametorecruiter = showfulllastnametorecruiter;
	}

	public Boolean getShowfullmobilephonetorecruiter() {
		return this.showfullmobilephonetorecruiter;
	}

	public void setShowfullmobilephonetorecruiter(Boolean showfullmobilephonetorecruiter) {
		this.showfullmobilephonetorecruiter = showfullmobilephonetorecruiter;
	}

	public Boolean getShowmissionendsoon() {
		return this.showmissionendsoon;
	}

	public void setShowmissionendsoon(Boolean showmissionendsoon) {
		this.showmissionendsoon = showmissionendsoon;
	}

	public Boolean getShowonline() {
		return this.showonline;
	}

	public void setShowonline(Boolean showonline) {
		this.showonline = showonline;
	}

	public Boolean getShowprofilesharedwithrecruiter() {
		return this.showprofilesharedwithrecruiter;
	}

	public void setShowprofilesharedwithrecruiter(Boolean showprofilesharedwithrecruiter) {
		this.showprofilesharedwithrecruiter = showprofilesharedwithrecruiter;
	}

	public Set<Partnerprofile> getPartnerprofiles() {
		return this.partnerprofiles;
	}

	public void setPartnerprofiles(Set<Partnerprofile> partnerprofiles) {
		this.partnerprofiles = partnerprofiles;
	}

	public Partnerprofile addPartnerprofile(Partnerprofile partnerprofile) {
		getPartnerprofiles().add(partnerprofile);
		partnerprofile.setPartnerpreference(this);

		return partnerprofile;
	}

	public Partnerprofile removePartnerprofile(Partnerprofile partnerprofile) {
		getPartnerprofiles().remove(partnerprofile);
		partnerprofile.setPartnerpreference(null);

		return partnerprofile;
	}

}