package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the gridpourcentagerepartition database table.
 * 
 */
@Entity
@NamedQuery(name="Gridpourcentagerepartition.findAll", query="SELECT g FROM Gridpourcentagerepartition g")
public class Gridpourcentagerepartition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GRIDPOURCENTAGEREPARTITION_IDGRIDPOURCENTAGEREPARTITION_GENERATOR", sequenceName="GUF.GRIDPOURCENTAGEREPARTITION_IDGRIDPOURCENTAGEREPARTITION_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GRIDPOURCENTAGEREPARTITION_IDGRIDPOURCENTAGEREPARTITION_GENERATOR")
	private Integer idgridpourcentagerepartition;

	private float businessopportunitybrought;

	private Timestamp datecreation;

	private float godfatherlevel1;

	private float godfatherlevel2;

	private float godfatherlevel3;

	private float godfatherlevel4;

	private float godfatherlevel5;

	private float groupmodel;

	private float personalproduction;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@OneToMany(mappedBy="gridpourcentagerepartition")
	private Set<Gridpourcentagerepartitionpartner> gridpourcentagerepartitionpartners;

	public Gridpourcentagerepartition() {
	}

	public Integer getIdgridpourcentagerepartition() {
		return this.idgridpourcentagerepartition;
	}

	public void setIdgridpourcentagerepartition(Integer idgridpourcentagerepartition) {
		this.idgridpourcentagerepartition = idgridpourcentagerepartition;
	}

	public float getBusinessopportunitybrought() {
		return this.businessopportunitybrought;
	}

	public void setBusinessopportunitybrought(float businessopportunitybrought) {
		this.businessopportunitybrought = businessopportunitybrought;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public float getGodfatherlevel1() {
		return this.godfatherlevel1;
	}

	public void setGodfatherlevel1(float godfatherlevel1) {
		this.godfatherlevel1 = godfatherlevel1;
	}

	public float getGodfatherlevel2() {
		return this.godfatherlevel2;
	}

	public void setGodfatherlevel2(float godfatherlevel2) {
		this.godfatherlevel2 = godfatherlevel2;
	}

	public float getGodfatherlevel3() {
		return this.godfatherlevel3;
	}

	public void setGodfatherlevel3(float godfatherlevel3) {
		this.godfatherlevel3 = godfatherlevel3;
	}

	public float getGodfatherlevel4() {
		return this.godfatherlevel4;
	}

	public void setGodfatherlevel4(float godfatherlevel4) {
		this.godfatherlevel4 = godfatherlevel4;
	}

	public float getGodfatherlevel5() {
		return this.godfatherlevel5;
	}

	public void setGodfatherlevel5(float godfatherlevel5) {
		this.godfatherlevel5 = godfatherlevel5;
	}

	public float getGroupmodel() {
		return this.groupmodel;
	}

	public void setGroupmodel(float groupmodel) {
		this.groupmodel = groupmodel;
	}

	public float getPersonalproduction() {
		return this.personalproduction;
	}

	public void setPersonalproduction(float personalproduction) {
		this.personalproduction = personalproduction;
	}

	public Set<Gridpourcentagerepartitionpartner> getGridpourcentagerepartitionpartners() {
		return this.gridpourcentagerepartitionpartners;
	}

	public void setGridpourcentagerepartitionpartners(Set<Gridpourcentagerepartitionpartner> gridpourcentagerepartitionpartners) {
		this.gridpourcentagerepartitionpartners = gridpourcentagerepartitionpartners;
	}

	public Gridpourcentagerepartitionpartner addGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		getGridpourcentagerepartitionpartners().add(gridpourcentagerepartitionpartner);
		gridpourcentagerepartitionpartner.setGridpourcentagerepartition(this);

		return gridpourcentagerepartitionpartner;
	}

	public Gridpourcentagerepartitionpartner removeGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		getGridpourcentagerepartitionpartners().remove(gridpourcentagerepartitionpartner);
		gridpourcentagerepartitionpartner.setGridpourcentagerepartition(null);

		return gridpourcentagerepartitionpartner;
	}

}