package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the packinvoicestatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Packinvoicestatushistory.findAll", query="SELECT p FROM Packinvoicestatushistory p")
public class Packinvoicestatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PACKINVOICESTATUSHISTORY_IDPACKINVOICESTATUSHISTORY_GENERATOR", sequenceName="GUF.PACKINVOICESTATUSHISTORY_IDPACKINVOICESTATUSHISTORY_SEQ" , allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PACKINVOICESTATUSHISTORY_IDPACKINVOICESTATUSHISTORY_GENERATOR")
	private Integer idpackinvoicestatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Packinvoice
	@ManyToOne
	@JoinColumn(name="idpackinvoice")
	private Packinvoice packinvoice;

	public Packinvoicestatushistory() {
	}

	public Integer getIdpackinvoicestatushistory() {
		return this.idpackinvoicestatushistory;
	}

	public void setIdpackinvoicestatushistory(Integer idpackinvoicestatushistory) {
		this.idpackinvoicestatushistory = idpackinvoicestatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Packinvoice getPackinvoice() {
		return this.packinvoice;
	}

	public void setPackinvoice(Packinvoice packinvoice) {
		this.packinvoice = packinvoice;
	}

}