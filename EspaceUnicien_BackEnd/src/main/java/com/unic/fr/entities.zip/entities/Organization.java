package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the organization database table.
 * 
 */
@Entity
@NamedQuery(name="Organization.findAll", query="SELECT o FROM Organization o")
public class Organization implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ORGANIZATION_IDORGANIZATION_GENERATOR", sequenceName="GUF.ORGANIZATION_IDORGANIZATION_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ORGANIZATION_IDORGANIZATION_GENERATOR")
	private Integer idorganization;

	private String organizationname;

	//bi-directional many-to-one association to Partner
	@OneToMany(mappedBy="organization")
	private Set<Partner> partners;

	public Organization() {
	}

	public Integer getIdorganization() {
		return this.idorganization;
	}

	public void setIdorganization(Integer idorganization) {
		this.idorganization = idorganization;
	}

	public String getOrganizationname() {
		return this.organizationname;
	}

	public void setOrganizationname(String organizationname) {
		this.organizationname = organizationname;
	}

	public Set<Partner> getPartners() {
		return this.partners;
	}

	public void setPartners(Set<Partner> partners) {
		this.partners = partners;
	}

	public Partner addPartner(Partner partner) {
		getPartners().add(partner);
		partner.setOrganization(this);

		return partner;
	}

	public Partner removePartner(Partner partner) {
		getPartners().remove(partner);
		partner.setOrganization(null);

		return partner;
	}

}