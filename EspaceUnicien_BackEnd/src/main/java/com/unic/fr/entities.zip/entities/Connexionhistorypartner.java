package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the connexionhistorypartner database table.
 * 
 */
@Entity
@NamedQuery(name="Connexionhistorypartner.findAll", query="SELECT c FROM Connexionhistorypartner c")
public class Connexionhistorypartner implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CONNEXIONHISTORYPARTNER_IDCONNEXIONHISTORYPARTNER_GENERATOR", sequenceName="GUF.CONNEXIONHISTORYPARTNER_IDCONNEXIONHISTORYPARTNER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CONNEXIONHISTORYPARTNER_IDCONNEXIONHISTORYPARTNER_GENERATOR")
	private Integer idconnexionhistorypartner;

	private Timestamp dateconnexion;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idpartner")
	private Partner partner;

	public Connexionhistorypartner() {
	}

	public Integer getIdconnexionhistorypartner() {
		return this.idconnexionhistorypartner;
	}

	public void setIdconnexionhistorypartner(Integer idconnexionhistorypartner) {
		this.idconnexionhistorypartner = idconnexionhistorypartner;
	}

	public Timestamp getDateconnexion() {
		return this.dateconnexion;
	}

	public void setDateconnexion(Timestamp dateconnexion) {
		this.dateconnexion = dateconnexion;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

}