package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the groupmodel database table.
 * 
 */
@Entity
@NamedQuery(name="Groupmodel.findAll", query="SELECT g FROM Groupmodel g")
public class Groupmodel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPMODEL_IDGROUPMODEL_GENERATOR", sequenceName="GUF.GROUPMODEL_IDGROUPMODEL_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPMODEL_IDGROUPMODEL_GENERATOR")
	private Integer idgroupmodel;

	private float amountwithouttax;

	private float amountwithtax;

	private String currency;

	private Timestamp datecreation;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="groupmodel")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Groupmodelstatushistory
	@OneToMany(mappedBy="groupmodel")
	private Set<Groupmodelstatushistory> groupmodelstatushistories;

	public Groupmodel() {
	}

	public Integer getIdgroupmodel() {
		return this.idgroupmodel;
	}

	public void setIdgroupmodel(Integer idgroupmodel) {
		this.idgroupmodel = idgroupmodel;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setGroupmodel(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setGroupmodel(null);

		return customerinvoice;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Set<Groupmodelstatushistory> getGroupmodelstatushistories() {
		return this.groupmodelstatushistories;
	}

	public void setGroupmodelstatushistories(Set<Groupmodelstatushistory> groupmodelstatushistories) {
		this.groupmodelstatushistories = groupmodelstatushistories;
	}

	public Groupmodelstatushistory addGroupmodelstatushistory(Groupmodelstatushistory groupmodelstatushistory) {
		getGroupmodelstatushistories().add(groupmodelstatushistory);
		groupmodelstatushistory.setGroupmodel(this);

		return groupmodelstatushistory;
	}

	public Groupmodelstatushistory removeGroupmodelstatushistory(Groupmodelstatushistory groupmodelstatushistory) {
		getGroupmodelstatushistories().remove(groupmodelstatushistory);
		groupmodelstatushistory.setGroupmodel(null);

		return groupmodelstatushistory;
	}

}