package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the paymentcustomerinvoice database table.
 * 
 */
@Entity
@NamedQuery(name="Paymentcustomerinvoice.findAll", query="SELECT p FROM Paymentcustomerinvoice p")
public class Paymentcustomerinvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PAYMENTCUSTOMERINVOICE_IDPAYMENTCUSTOMERINVOICE_GENERATOR", sequenceName="GUF.PAYMENTCUSTOMERINVOICE_IDPAYMENTCUSTOMERINVOICE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PAYMENTCUSTOMERINVOICE_IDPAYMENTCUSTOMERINVOICE_GENERATOR")
	private Integer idpaymentcustomerinvoice;

	private float amountwithtax;

	private String currency;

	private Timestamp datepayment;

	//bi-directional many-to-one association to Customerinvoice
	@ManyToOne
	@JoinColumn(name="idcustomerinvoice")
	private Customerinvoice customerinvoice;

	public Paymentcustomerinvoice() {
	}

	public Integer getIdpaymentcustomerinvoice() {
		return this.idpaymentcustomerinvoice;
	}

	public void setIdpaymentcustomerinvoice(Integer idpaymentcustomerinvoice) {
		this.idpaymentcustomerinvoice = idpaymentcustomerinvoice;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Timestamp getDatepayment() {
		return this.datepayment;
	}

	public void setDatepayment(Timestamp datepayment) {
		this.datepayment = datepayment;
	}

	public Customerinvoice getCustomerinvoice() {
		return this.customerinvoice;
	}

	public void setCustomerinvoice(Customerinvoice customerinvoice) {
		this.customerinvoice = customerinvoice;
	}

}