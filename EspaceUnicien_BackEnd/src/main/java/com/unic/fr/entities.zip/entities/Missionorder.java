package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the missionorder database table.
 * 
 */
@Entity
@NamedQuery(name="Missionorder.findAll", query="SELECT m FROM Missionorder m")
public class Missionorder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MISSIONORDER_IDMISSIONORDER_GENERATOR", sequenceName="GUF.MISSIONORDER_IDMISSIONORDER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MISSIONORDER_IDMISSIONORDER_GENERATOR")
	private Integer idmissionorder;

	@Temporal(TemporalType.DATE)
	private Date datecreation;

	private byte[] document;

	private String missionorderreferencenumber;

	//bi-directional many-to-one association to Assignment
	@ManyToOne
	@JoinColumn(name="idassignment")
	private Assignment assignment;

	public Missionorder() {
	}

	public Integer getIdmissionorder() {
		return this.idmissionorder;
	}

	public void setIdmissionorder(Integer idmissionorder) {
		this.idmissionorder = idmissionorder;
	}

	public Date getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Date datecreation) {
		this.datecreation = datecreation;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public String getMissionorderreferencenumber() {
		return this.missionorderreferencenumber;
	}

	public void setMissionorderreferencenumber(String missionorderreferencenumber) {
		this.missionorderreferencenumber = missionorderreferencenumber;
	}

	public Assignment getAssignment() {
		return this.assignment;
	}

	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}

}