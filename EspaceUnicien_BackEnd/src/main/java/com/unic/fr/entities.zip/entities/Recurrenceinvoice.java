package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the recurrenceinvoice database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrenceinvoice.findAll", query="SELECT r FROM Recurrenceinvoice r")
public class Recurrenceinvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCEINVOICE_IDRECCURENCEINVOICE_GENERATOR", sequenceName="GUF.RECURRENCEINVOICE_IDRECCURENCEINVOICE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCEINVOICE_IDRECCURENCEINVOICE_GENERATOR")
	private Integer idreccurenceinvoice;

	private String currency;

	private byte[] document;

	@Temporal(TemporalType.DATE)
	private Date duedate;

	private String recurrenceinvoicereferencenumber;

	private float taxamount;

	private float taxrate;

	private float totalamountwithouttax;

	private float totalamountwithtax;

	//bi-directional many-to-one association to Groupcompany
	@ManyToOne
	@JoinColumn(name="idrecipient")
	private Groupcompany groupcompany;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="idissuer")
	private Partner partner;

	//bi-directional many-to-one association to Recurrenceinvoicestatushistory
	@OneToMany(mappedBy="recurrenceinvoice")
	private Set<Recurrenceinvoicestatushistory> recurrenceinvoicestatushistories;

	//bi-directional many-to-many association to Recurrencelevel1
	@ManyToMany(mappedBy="recurrenceinvoices")
	private Set<Recurrencelevel1> recurrencelevel1s;

	//bi-directional many-to-many association to Recurrencelevel2
	@ManyToMany(mappedBy="recurrenceinvoices")
	private Set<Recurrencelevel2> recurrencelevel2s;

	//bi-directional many-to-many association to Recurrencelevel3
	@ManyToMany(mappedBy="recurrenceinvoices")
	private Set<Recurrencelevel3> recurrencelevel3s;

	//bi-directional many-to-many association to Recurrencelevel4
	@ManyToMany(mappedBy="recurrenceinvoices")
	private Set<Recurrencelevel4> recurrencelevel4s;

	//bi-directional many-to-many association to Recurrencelevel5
	@ManyToMany(mappedBy="recurrenceinvoices")
	private Set<Recurrencelevel5> recurrencelevel5s;

	public Recurrenceinvoice() {
	}

	public Integer getIdreccurenceinvoice() {
		return this.idreccurenceinvoice;
	}

	public void setIdreccurenceinvoice(Integer idreccurenceinvoice) {
		this.idreccurenceinvoice = idreccurenceinvoice;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public Date getDuedate() {
		return this.duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public String getRecurrenceinvoicereferencenumber() {
		return this.recurrenceinvoicereferencenumber;
	}

	public void setRecurrenceinvoicereferencenumber(String recurrenceinvoicereferencenumber) {
		this.recurrenceinvoicereferencenumber = recurrenceinvoicereferencenumber;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public float getTotalamountwithouttax() {
		return this.totalamountwithouttax;
	}

	public void setTotalamountwithouttax(float totalamountwithouttax) {
		this.totalamountwithouttax = totalamountwithouttax;
	}

	public float getTotalamountwithtax() {
		return this.totalamountwithtax;
	}

	public void setTotalamountwithtax(float totalamountwithtax) {
		this.totalamountwithtax = totalamountwithtax;
	}

	public Groupcompany getGroupcompany() {
		return this.groupcompany;
	}

	public void setGroupcompany(Groupcompany groupcompany) {
		this.groupcompany = groupcompany;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public Set<Recurrenceinvoicestatushistory> getRecurrenceinvoicestatushistories() {
		return this.recurrenceinvoicestatushistories;
	}

	public void setRecurrenceinvoicestatushistories(Set<Recurrenceinvoicestatushistory> recurrenceinvoicestatushistories) {
		this.recurrenceinvoicestatushistories = recurrenceinvoicestatushistories;
	}

	public Recurrenceinvoicestatushistory addRecurrenceinvoicestatushistory(Recurrenceinvoicestatushistory recurrenceinvoicestatushistory) {
		getRecurrenceinvoicestatushistories().add(recurrenceinvoicestatushistory);
		recurrenceinvoicestatushistory.setRecurrenceinvoice(this);

		return recurrenceinvoicestatushistory;
	}

	public Recurrenceinvoicestatushistory removeRecurrenceinvoicestatushistory(Recurrenceinvoicestatushistory recurrenceinvoicestatushistory) {
		getRecurrenceinvoicestatushistories().remove(recurrenceinvoicestatushistory);
		recurrenceinvoicestatushistory.setRecurrenceinvoice(null);

		return recurrenceinvoicestatushistory;
	}

	public Set<Recurrencelevel1> getRecurrencelevel1s() {
		return this.recurrencelevel1s;
	}

	public void setRecurrencelevel1s(Set<Recurrencelevel1> recurrencelevel1s) {
		this.recurrencelevel1s = recurrencelevel1s;
	}

	public Set<Recurrencelevel2> getRecurrencelevel2s() {
		return this.recurrencelevel2s;
	}

	public void setRecurrencelevel2s(Set<Recurrencelevel2> recurrencelevel2s) {
		this.recurrencelevel2s = recurrencelevel2s;
	}

	public Set<Recurrencelevel3> getRecurrencelevel3s() {
		return this.recurrencelevel3s;
	}

	public void setRecurrencelevel3s(Set<Recurrencelevel3> recurrencelevel3s) {
		this.recurrencelevel3s = recurrencelevel3s;
	}

	public Set<Recurrencelevel4> getRecurrencelevel4s() {
		return this.recurrencelevel4s;
	}

	public void setRecurrencelevel4s(Set<Recurrencelevel4> recurrencelevel4s) {
		this.recurrencelevel4s = recurrencelevel4s;
	}

	public Set<Recurrencelevel5> getRecurrencelevel5s() {
		return this.recurrencelevel5s;
	}

	public void setRecurrencelevel5s(Set<Recurrencelevel5> recurrencelevel5s) {
		this.recurrencelevel5s = recurrencelevel5s;
	}

}