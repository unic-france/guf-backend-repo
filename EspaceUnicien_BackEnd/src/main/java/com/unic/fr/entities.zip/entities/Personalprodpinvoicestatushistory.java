package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the personalprodpinvoicestatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Personalprodpinvoicestatushistory.findAll", query="SELECT p FROM Personalprodpinvoicestatushistory p")
public class Personalprodpinvoicestatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PERSONALPRODPINVOICESTATUSHISTORY_IDPPINVOICESTATUSHISTORY_GENERATOR", sequenceName="GUF.PERSONALPRODPINVOICESTATUSHISTORY_IDPPINVOICESTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PERSONALPRODPINVOICESTATUSHISTORY_IDPPINVOICESTATUSHISTORY_GENERATOR")
	private Integer idppinvoicestatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Personalproductioninvoice
	@ManyToOne
	@JoinColumn(name="idpersonalproductioninvoice")
	private Personalproductioninvoice personalproductioninvoice;

	public Personalprodpinvoicestatushistory() {
	}

	public Integer getIdppinvoicestatushistory() {
		return this.idppinvoicestatushistory;
	}

	public void setIdppinvoicestatushistory(Integer idppinvoicestatushistory) {
		this.idppinvoicestatushistory = idppinvoicestatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Personalproductioninvoice getPersonalproductioninvoice() {
		return this.personalproductioninvoice;
	}

	public void setPersonalproductioninvoice(Personalproductioninvoice personalproductioninvoice) {
		this.personalproductioninvoice = personalproductioninvoice;
	}

}