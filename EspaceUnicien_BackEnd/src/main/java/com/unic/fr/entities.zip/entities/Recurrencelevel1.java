package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the recurrencelevel1 database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel1.findAll", query="SELECT r FROM Recurrencelevel1 r")
public class Recurrencelevel1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL1_IDRECURRENCELEVEL1_GENERATOR", sequenceName="GUF.RECURRENCELEVEL1_IDRECURRENCELEVEL1_SEQ" , allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL1_IDRECURRENCELEVEL1_GENERATOR")
	private Integer idrecurrencelevel1;

	private float amountwithouttax;

	private float amountwithtax;

	private Boolean capitalized;

	private String currency;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="recurrencelevel1")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Partnernetwork
	@ManyToOne
	@JoinColumn(name="idpartnernetwork")
	private Partnernetwork partnernetwork;

	//bi-directional many-to-many association to Recurrenceinvoice
	@ManyToMany
	@JoinTable(
		name="recurrenceinvoicereccurencelevel1"
		, joinColumns={
			@JoinColumn(name="idrecurrencelevel1")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idreccurenceinvoice")
			}
		)
	private Set<Recurrenceinvoice> recurrenceinvoices;

	//bi-directional many-to-one association to Recurrencelevel1statushistory
	@OneToMany(mappedBy="recurrencelevel1")
	private Set<Recurrencelevel1statushistory> recurrencelevel1statushistories;

	public Recurrencelevel1() {
	}

	public Integer getIdrecurrencelevel1() {
		return this.idrecurrencelevel1;
	}

	public void setIdrecurrencelevel1(Integer idrecurrencelevel1) {
		this.idrecurrencelevel1 = idrecurrencelevel1;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public Boolean getCapitalized() {
		return this.capitalized;
	}

	public void setCapitalized(Boolean capitalized) {
		this.capitalized = capitalized;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setRecurrencelevel1(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setRecurrencelevel1(null);

		return customerinvoice;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Partnernetwork getPartnernetwork() {
		return this.partnernetwork;
	}

	public void setPartnernetwork(Partnernetwork partnernetwork) {
		this.partnernetwork = partnernetwork;
	}

	public Set<Recurrenceinvoice> getRecurrenceinvoices() {
		return this.recurrenceinvoices;
	}

	public void setRecurrenceinvoices(Set<Recurrenceinvoice> recurrenceinvoices) {
		this.recurrenceinvoices = recurrenceinvoices;
	}

	public Set<Recurrencelevel1statushistory> getRecurrencelevel1statushistories() {
		return this.recurrencelevel1statushistories;
	}

	public void setRecurrencelevel1statushistories(Set<Recurrencelevel1statushistory> recurrencelevel1statushistories) {
		this.recurrencelevel1statushistories = recurrencelevel1statushistories;
	}

	public Recurrencelevel1statushistory addRecurrencelevel1statushistory(Recurrencelevel1statushistory recurrencelevel1statushistory) {
		getRecurrencelevel1statushistories().add(recurrencelevel1statushistory);
		recurrencelevel1statushistory.setRecurrencelevel1(this);

		return recurrencelevel1statushistory;
	}

	public Recurrencelevel1statushistory removeRecurrencelevel1statushistory(Recurrencelevel1statushistory recurrencelevel1statushistory) {
		getRecurrencelevel1statushistories().remove(recurrencelevel1statushistory);
		recurrencelevel1statushistory.setRecurrencelevel1(null);

		return recurrencelevel1statushistory;
	}

}