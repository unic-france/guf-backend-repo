package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the qualification database table.
 * 
 */
@Entity
@NamedQuery(name="Qualification.findAll", query="SELECT q FROM Qualification q")
public class Qualification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="QUALIFICATION_IDQUALIFICATION_GENERATOR", sequenceName="GUF.QUALIFICATION_IDQUALIFICATION_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="QUALIFICATION_IDQUALIFICATION_GENERATOR")
	private Integer idqualification;

	private String currency;

	private String level;

	private Integer level1godchildnumbermaxallowed;

	private float minimumturnoveramount;

	private Boolean recurrencelevel1capitalized;

	private Boolean recurrencelevel2capitalized;

	private Boolean recurrencelevel3capitalized;

	private Boolean recurrencelevel4capitalized;

	private Boolean recurrencelevel5capitalized;

	//bi-directional many-to-one association to Qualificationpartner
	@OneToMany(mappedBy="qualification")
	private Set<Qualificationpartner> qualificationpartners;

	public Qualification() {
	}

	public Integer getIdqualification() {
		return this.idqualification;
	}

	public void setIdqualification(Integer idqualification) {
		this.idqualification = idqualification;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getLevel() {
		return this.level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public Integer getLevel1godchildnumbermaxallowed() {
		return this.level1godchildnumbermaxallowed;
	}

	public void setLevel1godchildnumbermaxallowed(Integer level1godchildnumbermaxallowed) {
		this.level1godchildnumbermaxallowed = level1godchildnumbermaxallowed;
	}

	public float getMinimumturnoveramount() {
		return this.minimumturnoveramount;
	}

	public void setMinimumturnoveramount(float minimumturnoveramount) {
		this.minimumturnoveramount = minimumturnoveramount;
	}

	public Boolean getRecurrencelevel1capitalized() {
		return this.recurrencelevel1capitalized;
	}

	public void setRecurrencelevel1capitalized(Boolean recurrencelevel1capitalized) {
		this.recurrencelevel1capitalized = recurrencelevel1capitalized;
	}

	public Boolean getRecurrencelevel2capitalized() {
		return this.recurrencelevel2capitalized;
	}

	public void setRecurrencelevel2capitalized(Boolean recurrencelevel2capitalized) {
		this.recurrencelevel2capitalized = recurrencelevel2capitalized;
	}

	public Boolean getRecurrencelevel3capitalized() {
		return this.recurrencelevel3capitalized;
	}

	public void setRecurrencelevel3capitalized(Boolean recurrencelevel3capitalized) {
		this.recurrencelevel3capitalized = recurrencelevel3capitalized;
	}

	public Boolean getRecurrencelevel4capitalized() {
		return this.recurrencelevel4capitalized;
	}

	public void setRecurrencelevel4capitalized(Boolean recurrencelevel4capitalized) {
		this.recurrencelevel4capitalized = recurrencelevel4capitalized;
	}

	public Boolean getRecurrencelevel5capitalized() {
		return this.recurrencelevel5capitalized;
	}

	public void setRecurrencelevel5capitalized(Boolean recurrencelevel5capitalized) {
		this.recurrencelevel5capitalized = recurrencelevel5capitalized;
	}

	public Set<Qualificationpartner> getQualificationpartners() {
		return this.qualificationpartners;
	}

	public void setQualificationpartners(Set<Qualificationpartner> qualificationpartners) {
		this.qualificationpartners = qualificationpartners;
	}

	public Qualificationpartner addQualificationpartner(Qualificationpartner qualificationpartner) {
		getQualificationpartners().add(qualificationpartner);
		qualificationpartner.setQualification(this);

		return qualificationpartner;
	}

	public Qualificationpartner removeQualificationpartner(Qualificationpartner qualificationpartner) {
		getQualificationpartners().remove(qualificationpartner);
		qualificationpartner.setQualification(null);

		return qualificationpartner;
	}

}