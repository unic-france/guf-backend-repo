package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the groupmodelstatushistory database table.
 * 
 */
@Entity
@NamedQuery(name="Groupmodelstatushistory.findAll", query="SELECT g FROM Groupmodelstatushistory g")
public class Groupmodelstatushistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPMODELSTATUSHISTORY_IDGROUPMODELSTATUSHISTORY_GENERATOR", sequenceName="GUF.GROUPMODELSTATUSHISTORY_IDGROUPMODELSTATUSHISTORY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPMODELSTATUSHISTORY_IDGROUPMODELSTATUSHISTORY_GENERATOR")
	private Integer idgroupmodelstatushistory;

	private Timestamp datecreation;

	private String status;

	//bi-directional many-to-one association to Groupmodel
	@ManyToOne
	@JoinColumn(name="idgroupmodel")
	private Groupmodel groupmodel;

	public Groupmodelstatushistory() {
	}

	public Integer getIdgroupmodelstatushistory() {
		return this.idgroupmodelstatushistory;
	}

	public void setIdgroupmodelstatushistory(Integer idgroupmodelstatushistory) {
		this.idgroupmodelstatushistory = idgroupmodelstatushistory;
	}

	public Timestamp getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Timestamp datecreation) {
		this.datecreation = datecreation;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Groupmodel getGroupmodel() {
		return this.groupmodel;
	}

	public void setGroupmodel(Groupmodel groupmodel) {
		this.groupmodel = groupmodel;
	}

}