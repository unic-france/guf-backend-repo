package com.unic.fr.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the customerinvoice database table.
 * 
 */
@Entity
@NamedQuery(name="Customerinvoice.findAll", query="SELECT c FROM Customerinvoice c")
public class Customerinvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CUSTOMERINVOICE_IDCUSTOMERINVOICE_GENERATOR", sequenceName="GUF.CUSTOMERINVOICE_IDCUSTOMERINVOICE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CUSTOMERINVOICE_IDCUSTOMERINVOICE_GENERATOR")
	private Integer idcustomerinvoice;

	private byte[] activityreportdocument;

	private String currency;

	private String customerinvoicereferencenumber;

	private byte[] document;

	private float dueamount;

	@Temporal(TemporalType.DATE)
	private Date duedate;

	private float numberofdaysworked;

	@Temporal(TemporalType.DATE)
	private Date period;

	private float taxamount;

	private float taxrate;

	private float totalamountwithouttax;

	private float totalamountwithtax;

	//bi-directional many-to-one association to Creditnote
	@OneToMany(mappedBy="customerinvoice")
	private Set<Creditnote> creditnotes;

	//bi-directional many-to-one association to Assignment
	@ManyToOne
	@JoinColumn(name="idassignment")
	private Assignment assignment;

	//bi-directional many-to-one association to Businessopportunitybrought
	@ManyToOne
	@JoinColumn(name="idbusinessopportunitybrought")
	private Businessopportunitybrought businessopportunitybrought;

	//bi-directional many-to-one association to Customerinvoicedetail
	@ManyToOne
	@JoinColumn(name="idcustomerinvoicedetails")
	private Customerinvoicedetail customerinvoicedetail;

	//bi-directional many-to-one association to Flagcustomerinvoice
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="idflagcustomerinvoice")
	private Flagcustomerinvoice flagcustomerinvoice;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Groupcompany
	@ManyToOne
	@JoinColumn(name="idissuer")
	private Groupcompany groupcompany;

	//bi-directional many-to-one association to Groupmodel
	@ManyToOne
	@JoinColumn(name="idgroupmodel")
	private Groupmodel groupmodel;

	//bi-directional many-to-one association to Personalproductioninvoice
	@ManyToOne
	@JoinColumn(name="idpersonalproductioninvoice")
	private Personalproductioninvoice personalproductioninvoice;

	//bi-directional many-to-one association to Recurrencegroup
	@ManyToOne
	@JoinColumn(name="idrecurrencegroup")
	private Recurrencegroup recurrencegroup;

	//bi-directional many-to-one association to Recurrencelevel1
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel1")
	private Recurrencelevel1 recurrencelevel1;

	//bi-directional many-to-one association to Recurrencelevel2
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel2")
	private Recurrencelevel2 recurrencelevel2;

	//bi-directional many-to-one association to Recurrencelevel3
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel3")
	private Recurrencelevel3 recurrencelevel3;

	//bi-directional many-to-one association to Recurrencelevel4
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel4")
	private Recurrencelevel4 recurrencelevel4;

	//bi-directional many-to-one association to Recurrencelevel5
	@ManyToOne
	@JoinColumn(name="idrecurrencelevel5")
	private Recurrencelevel5 recurrencelevel5;

	//bi-directional many-to-one association to Customerinvoicestatushistory
	@OneToMany(mappedBy="customerinvoice", cascade=CascadeType.ALL)
	private Set<Customerinvoicestatushistory> customerinvoicestatushistories;

	//bi-directional many-to-one association to Paymentcustomerinvoice
	@OneToMany(mappedBy="customerinvoice")
	private Set<Paymentcustomerinvoice> paymentcustomerinvoices;

	public Customerinvoice() {
	}

	public Integer getIdcustomerinvoice() {
		return this.idcustomerinvoice;
	}

	public void setIdcustomerinvoice(Integer idcustomerinvoice) {
		this.idcustomerinvoice = idcustomerinvoice;
	}

	public byte[] getActivityreportdocument() {
		return this.activityreportdocument;
	}

	public void setActivityreportdocument(byte[] activityreportdocument) {
		this.activityreportdocument = activityreportdocument;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCustomerinvoicereferencenumber() {
		return this.customerinvoicereferencenumber;
	}

	public void setCustomerinvoicereferencenumber(String customerinvoicereferencenumber) {
		this.customerinvoicereferencenumber = customerinvoicereferencenumber;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public float getDueamount() {
		return this.dueamount;
	}

	public void setDueamount(float dueamount) {
		this.dueamount = dueamount;
	}

	public Date getDuedate() {
		return this.duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public float getNumberofdaysworked() {
		return this.numberofdaysworked;
	}

	public void setNumberofdaysworked(float numberofdaysworked) {
		this.numberofdaysworked = numberofdaysworked;
	}

	public Date getPeriod() {
		return this.period;
	}

	public void setPeriod(Date period) {
		this.period = period;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public float getTotalamountwithouttax() {
		return this.totalamountwithouttax;
	}

	public void setTotalamountwithouttax(float totalamountwithouttax) {
		this.totalamountwithouttax = totalamountwithouttax;
	}

	public float getTotalamountwithtax() {
		return this.totalamountwithtax;
	}

	public void setTotalamountwithtax(float totalamountwithtax) {
		this.totalamountwithtax = totalamountwithtax;
	}

	public Set<Creditnote> getCreditnotes() {
		return this.creditnotes;
	}

	public void setCreditnotes(Set<Creditnote> creditnotes) {
		this.creditnotes = creditnotes;
	}

	public Creditnote addCreditnote(Creditnote creditnote) {
		getCreditnotes().add(creditnote);
		creditnote.setCustomerinvoice(this);

		return creditnote;
	}

	public Creditnote removeCreditnote(Creditnote creditnote) {
		getCreditnotes().remove(creditnote);
		creditnote.setCustomerinvoice(null);

		return creditnote;
	}

	public Assignment getAssignment() {
		return this.assignment;
	}

	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}

	public Businessopportunitybrought getBusinessopportunitybrought() {
		return this.businessopportunitybrought;
	}

	public void setBusinessopportunitybrought(Businessopportunitybrought businessopportunitybrought) {
		this.businessopportunitybrought = businessopportunitybrought;
	}

	public Customerinvoicedetail getCustomerinvoicedetail() {
		return this.customerinvoicedetail;
	}

	public void setCustomerinvoicedetail(Customerinvoicedetail customerinvoicedetail) {
		this.customerinvoicedetail = customerinvoicedetail;
	}

	public Flagcustomerinvoice getFlagcustomerinvoice() {
		return this.flagcustomerinvoice;
	}

	public void setFlagcustomerinvoice(Flagcustomerinvoice flagcustomerinvoice) {
		this.flagcustomerinvoice = flagcustomerinvoice;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Groupcompany getGroupcompany() {
		return this.groupcompany;
	}

	public void setGroupcompany(Groupcompany groupcompany) {
		this.groupcompany = groupcompany;
	}

	public Groupmodel getGroupmodel() {
		return this.groupmodel;
	}

	public void setGroupmodel(Groupmodel groupmodel) {
		this.groupmodel = groupmodel;
	}

	public Personalproductioninvoice getPersonalproductioninvoice() {
		return this.personalproductioninvoice;
	}

	public void setPersonalproductioninvoice(Personalproductioninvoice personalproductioninvoice) {
		this.personalproductioninvoice = personalproductioninvoice;
	}

	public Recurrencegroup getRecurrencegroup() {
		return this.recurrencegroup;
	}

	public void setRecurrencegroup(Recurrencegroup recurrencegroup) {
		this.recurrencegroup = recurrencegroup;
	}

	public Recurrencelevel1 getRecurrencelevel1() {
		return this.recurrencelevel1;
	}

	public void setRecurrencelevel1(Recurrencelevel1 recurrencelevel1) {
		this.recurrencelevel1 = recurrencelevel1;
	}

	public Recurrencelevel2 getRecurrencelevel2() {
		return this.recurrencelevel2;
	}

	public void setRecurrencelevel2(Recurrencelevel2 recurrencelevel2) {
		this.recurrencelevel2 = recurrencelevel2;
	}

	public Recurrencelevel3 getRecurrencelevel3() {
		return this.recurrencelevel3;
	}

	public void setRecurrencelevel3(Recurrencelevel3 recurrencelevel3) {
		this.recurrencelevel3 = recurrencelevel3;
	}

	public Recurrencelevel4 getRecurrencelevel4() {
		return this.recurrencelevel4;
	}

	public void setRecurrencelevel4(Recurrencelevel4 recurrencelevel4) {
		this.recurrencelevel4 = recurrencelevel4;
	}

	public Recurrencelevel5 getRecurrencelevel5() {
		return this.recurrencelevel5;
	}

	public void setRecurrencelevel5(Recurrencelevel5 recurrencelevel5) {
		this.recurrencelevel5 = recurrencelevel5;
	}

	public Set<Customerinvoicestatushistory> getCustomerinvoicestatushistories() {
		return this.customerinvoicestatushistories;
	}

	public void setCustomerinvoicestatushistories(Set<Customerinvoicestatushistory> customerinvoicestatushistories) {
		this.customerinvoicestatushistories = customerinvoicestatushistories;
	}

	public Customerinvoicestatushistory addCustomerinvoicestatushistory(Customerinvoicestatushistory customerinvoicestatushistory) {
		getCustomerinvoicestatushistories().add(customerinvoicestatushistory);
		customerinvoicestatushistory.setCustomerinvoice(this);

		return customerinvoicestatushistory;
	}

	public Customerinvoicestatushistory removeCustomerinvoicestatushistory(Customerinvoicestatushistory customerinvoicestatushistory) {
		getCustomerinvoicestatushistories().remove(customerinvoicestatushistory);
		customerinvoicestatushistory.setCustomerinvoice(null);

		return customerinvoicestatushistory;
	}

	public Set<Paymentcustomerinvoice> getPaymentcustomerinvoices() {
		return this.paymentcustomerinvoices;
	}

	public void setPaymentcustomerinvoices(Set<Paymentcustomerinvoice> paymentcustomerinvoices) {
		this.paymentcustomerinvoices = paymentcustomerinvoices;
	}

	public Paymentcustomerinvoice addPaymentcustomerinvoice(Paymentcustomerinvoice paymentcustomerinvoice) {
		getPaymentcustomerinvoices().add(paymentcustomerinvoice);
		paymentcustomerinvoice.setCustomerinvoice(this);

		return paymentcustomerinvoice;
	}

	public Paymentcustomerinvoice removePaymentcustomerinvoice(Paymentcustomerinvoice paymentcustomerinvoice) {
		getPaymentcustomerinvoices().remove(paymentcustomerinvoice);
		paymentcustomerinvoice.setCustomerinvoice(null);

		return paymentcustomerinvoice;
	}

}