package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the groupstaffmemberprofile database table.
 * 
 */
@Entity
@NamedQuery(name="Groupstaffmemberprofile.findAll", query="SELECT g FROM Groupstaffmemberprofile g")
public class Groupstaffmemberprofile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GROUPSTAFFMEMBERPROFILE_IDGROUPSTAFFMEMBERPROFILE_GENERATOR", sequenceName="GUF.GROUPSTAFFMEMBERPROFILE_IDGROUPSTAFFMEMBERPROFILE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GROUPSTAFFMEMBERPROFILE_IDGROUPSTAFFMEMBERPROFILE_GENERATOR")
	private Integer idgroupstaffmemberprofile;

	private String firstname;

	private String name;

	private byte[] picture;

	private String summary;

	private String title;

	//bi-directional many-to-one association to Groupstaffmember
	@OneToMany(mappedBy="groupstaffmemberprofile")
	private Set<Groupstaffmember> groupstaffmembers;

	//bi-directional many-to-one association to Groupstaffmembercontact
	@ManyToOne
	@JoinColumn(name="idgroupstaffmembercontact")
	private Groupstaffmembercontact groupstaffmembercontact;

	public Groupstaffmemberprofile() {
	}

	public Integer getIdgroupstaffmemberprofile() {
		return this.idgroupstaffmemberprofile;
	}

	public void setIdgroupstaffmemberprofile(Integer idgroupstaffmemberprofile) {
		this.idgroupstaffmemberprofile = idgroupstaffmemberprofile;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte[] getPicture() {
		return this.picture;
	}

	public void setPicture(byte[] picture) {
		this.picture = picture;
	}

	public String getSummary() {
		return this.summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Set<Groupstaffmember> getGroupstaffmembers() {
		return this.groupstaffmembers;
	}

	public void setGroupstaffmembers(Set<Groupstaffmember> groupstaffmembers) {
		this.groupstaffmembers = groupstaffmembers;
	}

	public Groupstaffmember addGroupstaffmember(Groupstaffmember groupstaffmember) {
		getGroupstaffmembers().add(groupstaffmember);
		groupstaffmember.setGroupstaffmemberprofile(this);

		return groupstaffmember;
	}

	public Groupstaffmember removeGroupstaffmember(Groupstaffmember groupstaffmember) {
		getGroupstaffmembers().remove(groupstaffmember);
		groupstaffmember.setGroupstaffmemberprofile(null);

		return groupstaffmember;
	}

	public Groupstaffmembercontact getGroupstaffmembercontact() {
		return this.groupstaffmembercontact;
	}

	public void setGroupstaffmembercontact(Groupstaffmembercontact groupstaffmembercontact) {
		this.groupstaffmembercontact = groupstaffmembercontact;
	}

}