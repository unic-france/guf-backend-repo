package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the contract database table.
 * 
 */
@Entity
@NamedQuery(name="Contract.findAll", query="SELECT c FROM Contract c")
public class Contract implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CONTRACT_IDCONTRACT_GENERATOR", sequenceName="GUF.CONTRACT_IDCONTRACT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CONTRACT_IDCONTRACT_GENERATOR")
	private Integer idcontract;

	private String contractreferencenumber;

	@Temporal(TemporalType.DATE)
	private Date datecreation;

	private byte[] document;

	//bi-directional many-to-many association to Assignment
	@ManyToMany
	@JoinTable(
		name="assignmentcontract"
		, joinColumns={
			@JoinColumn(name="idcontract")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idassignment")
			}
		)
	private Set<Assignment> assignments;

	public Contract() {
	}

	public Integer getIdcontract() {
		return this.idcontract;
	}

	public void setIdcontract(Integer idcontract) {
		this.idcontract = idcontract;
	}

	public String getContractreferencenumber() {
		return this.contractreferencenumber;
	}

	public void setContractreferencenumber(String contractreferencenumber) {
		this.contractreferencenumber = contractreferencenumber;
	}

	public Date getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Date datecreation) {
		this.datecreation = datecreation;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public Set<Assignment> getAssignments() {
		return this.assignments;
	}

	public void setAssignments(Set<Assignment> assignments) {
		this.assignments = assignments;
	}

}