package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the purchaseorder database table.
 * 
 */
@Entity
@NamedQuery(name="Purchaseorder.findAll", query="SELECT p FROM Purchaseorder p")
public class Purchaseorder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PURCHASEORDER_IDPURCHASEORDER_GENERATOR", sequenceName="GUF.PURCHASEORDER_IDPURCHASEORDER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PURCHASEORDER_IDPURCHASEORDER_GENERATOR")
	private Integer idpurchaseorder;

	@Temporal(TemporalType.DATE)
	private Date datecreation;

	private byte[] document;

	private String purchaseorderreferencenumber;

	//bi-directional many-to-one association to Assignment
	@ManyToOne
	@JoinColumn(name="idassignment")
	private Assignment assignment;

	public Purchaseorder() {
	}

	public Integer getIdpurchaseorder() {
		return this.idpurchaseorder;
	}

	public void setIdpurchaseorder(Integer idpurchaseorder) {
		this.idpurchaseorder = idpurchaseorder;
	}

	public Date getDatecreation() {
		return this.datecreation;
	}

	public void setDatecreation(Date datecreation) {
		this.datecreation = datecreation;
	}

	public byte[] getDocument() {
		return this.document;
	}

	public void setDocument(byte[] document) {
		this.document = document;
	}

	public String getPurchaseorderreferencenumber() {
		return this.purchaseorderreferencenumber;
	}

	public void setPurchaseorderreferencenumber(String purchaseorderreferencenumber) {
		this.purchaseorderreferencenumber = purchaseorderreferencenumber;
	}

	public Assignment getAssignment() {
		return this.assignment;
	}

	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}

}