package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the recurrencelevel2 database table.
 * 
 */
@Entity
@NamedQuery(name="Recurrencelevel2.findAll", query="SELECT r FROM Recurrencelevel2 r")
public class Recurrencelevel2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="RECURRENCELEVEL2_IDRECURRENCELEVEL2_GENERATOR", sequenceName="GUF.RECURRENCELEVEL2_IDRECURRENCELEVEL2_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RECURRENCELEVEL2_IDRECURRENCELEVEL2_GENERATOR")
	private Integer idrecurrencelevel2;

	private float amountwithouttax;

	private float amountwithtax;

	private Boolean capitalized;

	private String currency;

	private float taxamount;

	private float taxrate;

	//bi-directional many-to-one association to Customerinvoice
	@OneToMany(mappedBy="recurrencelevel2")
	private Set<Customerinvoice> customerinvoices;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@ManyToOne
	@JoinColumn(name="idgridpourcentagereppart")
	private Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner;

	//bi-directional many-to-one association to Partnernetwork
	@ManyToOne
	@JoinColumn(name="idpartnernetwork")
	private Partnernetwork partnernetwork;

	//bi-directional many-to-many association to Recurrenceinvoice
	@ManyToMany
	@JoinTable(
		name="recurrenceinvoicereccurencelevel2"
		, joinColumns={
			@JoinColumn(name="idrecurrencelevel2")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idreccurenceinvoice")
			}
		)
	private Set<Recurrenceinvoice> recurrenceinvoices;

	//bi-directional many-to-one association to Recurrencelevel2statushistory
	@OneToMany(mappedBy="recurrencelevel2")
	private Set<Recurrencelevel2statushistory> recurrencelevel2statushistories;

	public Recurrencelevel2() {
	}

	public Integer getIdrecurrencelevel2() {
		return this.idrecurrencelevel2;
	}

	public void setIdrecurrencelevel2(Integer idrecurrencelevel2) {
		this.idrecurrencelevel2 = idrecurrencelevel2;
	}

	public float getAmountwithouttax() {
		return this.amountwithouttax;
	}

	public void setAmountwithouttax(float amountwithouttax) {
		this.amountwithouttax = amountwithouttax;
	}

	public float getAmountwithtax() {
		return this.amountwithtax;
	}

	public void setAmountwithtax(float amountwithtax) {
		this.amountwithtax = amountwithtax;
	}

	public Boolean getCapitalized() {
		return this.capitalized;
	}

	public void setCapitalized(Boolean capitalized) {
		this.capitalized = capitalized;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getTaxamount() {
		return this.taxamount;
	}

	public void setTaxamount(float taxamount) {
		this.taxamount = taxamount;
	}

	public float getTaxrate() {
		return this.taxrate;
	}

	public void setTaxrate(float taxrate) {
		this.taxrate = taxrate;
	}

	public Set<Customerinvoice> getCustomerinvoices() {
		return this.customerinvoices;
	}

	public void setCustomerinvoices(Set<Customerinvoice> customerinvoices) {
		this.customerinvoices = customerinvoices;
	}

	public Customerinvoice addCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().add(customerinvoice);
		customerinvoice.setRecurrencelevel2(this);

		return customerinvoice;
	}

	public Customerinvoice removeCustomerinvoice(Customerinvoice customerinvoice) {
		getCustomerinvoices().remove(customerinvoice);
		customerinvoice.setRecurrencelevel2(null);

		return customerinvoice;
	}

	public Gridpourcentagerepartitionpartner getGridpourcentagerepartitionpartner() {
		return this.gridpourcentagerepartitionpartner;
	}

	public void setGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		this.gridpourcentagerepartitionpartner = gridpourcentagerepartitionpartner;
	}

	public Partnernetwork getPartnernetwork() {
		return this.partnernetwork;
	}

	public void setPartnernetwork(Partnernetwork partnernetwork) {
		this.partnernetwork = partnernetwork;
	}

	public Set<Recurrenceinvoice> getRecurrenceinvoices() {
		return this.recurrenceinvoices;
	}

	public void setRecurrenceinvoices(Set<Recurrenceinvoice> recurrenceinvoices) {
		this.recurrenceinvoices = recurrenceinvoices;
	}

	public Set<Recurrencelevel2statushistory> getRecurrencelevel2statushistories() {
		return this.recurrencelevel2statushistories;
	}

	public void setRecurrencelevel2statushistories(Set<Recurrencelevel2statushistory> recurrencelevel2statushistories) {
		this.recurrencelevel2statushistories = recurrencelevel2statushistories;
	}

	public Recurrencelevel2statushistory addRecurrencelevel2statushistory(Recurrencelevel2statushistory recurrencelevel2statushistory) {
		getRecurrencelevel2statushistories().add(recurrencelevel2statushistory);
		recurrencelevel2statushistory.setRecurrencelevel2(this);

		return recurrencelevel2statushistory;
	}

	public Recurrencelevel2statushistory removeRecurrencelevel2statushistory(Recurrencelevel2statushistory recurrencelevel2statushistory) {
		getRecurrencelevel2statushistories().remove(recurrencelevel2statushistory);
		recurrencelevel2statushistory.setRecurrencelevel2(null);

		return recurrencelevel2statushistory;
	}

}