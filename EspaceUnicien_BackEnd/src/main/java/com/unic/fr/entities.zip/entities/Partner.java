package com.unic.fr.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the partner database table.
 * 
 */
@Entity
@NamedQuery(name="Partner.findAll", query="SELECT p FROM Partner p")
public class Partner implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNER_IDPARTNER_GENERATOR", sequenceName="GUF.PARTNER_IDPARTNER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNER_IDPARTNER_GENERATOR")
	private Integer idpartner;

	private String puid;

	//bi-directional many-to-one association to Assignment
	@OneToMany(mappedBy="partner1")
	private Set<Assignment> assignments1;

	//bi-directional many-to-one association to Assignment
	@OneToMany(mappedBy="partner2")
	private Set<Assignment> assignments2;

	//bi-directional many-to-one association to Businessopportunitybrought
	@OneToMany(mappedBy="partner")
	private Set<Businessopportunitybrought> businessopportunitybroughts;

	//bi-directional many-to-one association to Businessopportunitybroughtinvoice
	@OneToMany(mappedBy="partner")
	private Set<Businessopportunitybroughtinvoice> businessopportunitybroughtinvoices;

	//bi-directional many-to-one association to Connexionhistorypartner
	@OneToMany(mappedBy="partner")
	private Set<Connexionhistorypartner> connexionhistorypartners;

	//bi-directional many-to-one association to Gridpourcentagerepartitionpartner
	@OneToMany(mappedBy="partner")
	private Set<Gridpourcentagerepartitionpartner> gridpourcentagerepartitionpartners;

	//bi-directional many-to-one association to Network
	@OneToMany(mappedBy="partner1")
	private Set<Network> networks1;

	//bi-directional many-to-one association to Network
	@OneToMany(mappedBy="partner2")
	private Set<Network> networks2;

	//bi-directional many-to-one association to Network
	@OneToMany(mappedBy="partner3")
	private Set<Network> networks3;

	//bi-directional many-to-one association to Network
	@OneToMany(mappedBy="partner4")
	private Set<Network> networks4;

	//bi-directional many-to-one association to Network
	@OneToMany(mappedBy="partner5")
	private Set<Network> networks5;

	//bi-directional many-to-one association to Packpartner
	@OneToMany(mappedBy="partner")
	private Set<Packpartner> packpartners;

	//bi-directional many-to-many association to Groupstaffmember
	@ManyToMany
	@JoinTable(
		name="groupstaffmemberpartner"
		, joinColumns={
			@JoinColumn(name="idpartner")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idgroupstaffmember")
			}
		)
	private Set<Groupstaffmember> groupstaffmembers;

	//bi-directional many-to-one association to Organization
	@ManyToOne
	@JoinColumn(name="idorganization")
	private Organization organization;

	//bi-directional many-to-one association to Partnerbankingdetail
	@ManyToOne
	@JoinColumn(name="idpartnerbankingdetails")
	private Partnerbankingdetail partnerbankingdetail;

	//bi-directional many-to-one association to Partnercompany
	@ManyToOne
	@JoinColumn(name="idpartnercompany")
	private Partnercompany partnercompany;

	//bi-directional many-to-one association to Partnerprofile
	@ManyToOne
	@JoinColumn(name="idpartnerprofile")
	private Partnerprofile partnerprofile;

	//bi-directional many-to-one association to Partnernetwork
	@OneToMany(mappedBy="partner")
	private Set<Partnernetwork> partnernetworks;

	//bi-directional many-to-one association to Personalproductioninvoice
	@OneToMany(mappedBy="partner")
	private Set<Personalproductioninvoice> personalproductioninvoices;

	//bi-directional many-to-one association to Qualificationpartner
	@OneToMany(mappedBy="partner")
	private Set<Qualificationpartner> qualificationpartners;

	//bi-directional many-to-one association to Recurrenceinvoice
	@OneToMany(mappedBy="partner")
	private Set<Recurrenceinvoice> recurrenceinvoices;

	public Partner() {
	}

	public Integer getIdpartner() {
		return this.idpartner;
	}

	public void setIdpartner(Integer idpartner) {
		this.idpartner = idpartner;
	}

	public String getPuid() {
		return this.puid;
	}

	public void setPuid(String puid) {
		this.puid = puid;
	}

	public Set<Assignment> getAssignments1() {
		return this.assignments1;
	}

	public void setAssignments1(Set<Assignment> assignments1) {
		this.assignments1 = assignments1;
	}

	public Assignment addAssignments1(Assignment assignments1) {
		getAssignments1().add(assignments1);
		assignments1.setPartner1(this);

		return assignments1;
	}

	public Assignment removeAssignments1(Assignment assignments1) {
		getAssignments1().remove(assignments1);
		assignments1.setPartner1(null);

		return assignments1;
	}

	public Set<Assignment> getAssignments2() {
		return this.assignments2;
	}

	public void setAssignments2(Set<Assignment> assignments2) {
		this.assignments2 = assignments2;
	}

	public Assignment addAssignments2(Assignment assignments2) {
		getAssignments2().add(assignments2);
		assignments2.setPartner2(this);

		return assignments2;
	}

	public Assignment removeAssignments2(Assignment assignments2) {
		getAssignments2().remove(assignments2);
		assignments2.setPartner2(null);

		return assignments2;
	}

	public Set<Businessopportunitybrought> getBusinessopportunitybroughts() {
		return this.businessopportunitybroughts;
	}

	public void setBusinessopportunitybroughts(Set<Businessopportunitybrought> businessopportunitybroughts) {
		this.businessopportunitybroughts = businessopportunitybroughts;
	}

	public Businessopportunitybrought addBusinessopportunitybrought(Businessopportunitybrought businessopportunitybrought) {
		getBusinessopportunitybroughts().add(businessopportunitybrought);
		businessopportunitybrought.setPartner(this);

		return businessopportunitybrought;
	}

	public Businessopportunitybrought removeBusinessopportunitybrought(Businessopportunitybrought businessopportunitybrought) {
		getBusinessopportunitybroughts().remove(businessopportunitybrought);
		businessopportunitybrought.setPartner(null);

		return businessopportunitybrought;
	}

	public Set<Businessopportunitybroughtinvoice> getBusinessopportunitybroughtinvoices() {
		return this.businessopportunitybroughtinvoices;
	}

	public void setBusinessopportunitybroughtinvoices(Set<Businessopportunitybroughtinvoice> businessopportunitybroughtinvoices) {
		this.businessopportunitybroughtinvoices = businessopportunitybroughtinvoices;
	}

	public Businessopportunitybroughtinvoice addBusinessopportunitybroughtinvoice(Businessopportunitybroughtinvoice businessopportunitybroughtinvoice) {
		getBusinessopportunitybroughtinvoices().add(businessopportunitybroughtinvoice);
		businessopportunitybroughtinvoice.setPartner(this);

		return businessopportunitybroughtinvoice;
	}

	public Businessopportunitybroughtinvoice removeBusinessopportunitybroughtinvoice(Businessopportunitybroughtinvoice businessopportunitybroughtinvoice) {
		getBusinessopportunitybroughtinvoices().remove(businessopportunitybroughtinvoice);
		businessopportunitybroughtinvoice.setPartner(null);

		return businessopportunitybroughtinvoice;
	}

	public Set<Connexionhistorypartner> getConnexionhistorypartners() {
		return this.connexionhistorypartners;
	}

	public void setConnexionhistorypartners(Set<Connexionhistorypartner> connexionhistorypartners) {
		this.connexionhistorypartners = connexionhistorypartners;
	}

	public Connexionhistorypartner addConnexionhistorypartner(Connexionhistorypartner connexionhistorypartner) {
		getConnexionhistorypartners().add(connexionhistorypartner);
		connexionhistorypartner.setPartner(this);

		return connexionhistorypartner;
	}

	public Connexionhistorypartner removeConnexionhistorypartner(Connexionhistorypartner connexionhistorypartner) {
		getConnexionhistorypartners().remove(connexionhistorypartner);
		connexionhistorypartner.setPartner(null);

		return connexionhistorypartner;
	}

	public Set<Gridpourcentagerepartitionpartner> getGridpourcentagerepartitionpartners() {
		return this.gridpourcentagerepartitionpartners;
	}

	public void setGridpourcentagerepartitionpartners(Set<Gridpourcentagerepartitionpartner> gridpourcentagerepartitionpartners) {
		this.gridpourcentagerepartitionpartners = gridpourcentagerepartitionpartners;
	}

	public Gridpourcentagerepartitionpartner addGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		getGridpourcentagerepartitionpartners().add(gridpourcentagerepartitionpartner);
		gridpourcentagerepartitionpartner.setPartner(this);

		return gridpourcentagerepartitionpartner;
	}

	public Gridpourcentagerepartitionpartner removeGridpourcentagerepartitionpartner(Gridpourcentagerepartitionpartner gridpourcentagerepartitionpartner) {
		getGridpourcentagerepartitionpartners().remove(gridpourcentagerepartitionpartner);
		gridpourcentagerepartitionpartner.setPartner(null);

		return gridpourcentagerepartitionpartner;
	}

	public Set<Network> getNetworks1() {
		return this.networks1;
	}

	public void setNetworks1(Set<Network> networks1) {
		this.networks1 = networks1;
	}

	public Network addNetworks1(Network networks1) {
		getNetworks1().add(networks1);
		networks1.setPartner1(this);

		return networks1;
	}

	public Network removeNetworks1(Network networks1) {
		getNetworks1().remove(networks1);
		networks1.setPartner1(null);

		return networks1;
	}

	public Set<Network> getNetworks2() {
		return this.networks2;
	}

	public void setNetworks2(Set<Network> networks2) {
		this.networks2 = networks2;
	}

	public Network addNetworks2(Network networks2) {
		getNetworks2().add(networks2);
		networks2.setPartner2(this);

		return networks2;
	}

	public Network removeNetworks2(Network networks2) {
		getNetworks2().remove(networks2);
		networks2.setPartner2(null);

		return networks2;
	}

	public Set<Network> getNetworks3() {
		return this.networks3;
	}

	public void setNetworks3(Set<Network> networks3) {
		this.networks3 = networks3;
	}

	public Network addNetworks3(Network networks3) {
		getNetworks3().add(networks3);
		networks3.setPartner3(this);

		return networks3;
	}

	public Network removeNetworks3(Network networks3) {
		getNetworks3().remove(networks3);
		networks3.setPartner3(null);

		return networks3;
	}

	public Set<Network> getNetworks4() {
		return this.networks4;
	}

	public void setNetworks4(Set<Network> networks4) {
		this.networks4 = networks4;
	}

	public Network addNetworks4(Network networks4) {
		getNetworks4().add(networks4);
		networks4.setPartner4(this);

		return networks4;
	}

	public Network removeNetworks4(Network networks4) {
		getNetworks4().remove(networks4);
		networks4.setPartner4(null);

		return networks4;
	}

	public Set<Network> getNetworks5() {
		return this.networks5;
	}

	public void setNetworks5(Set<Network> networks5) {
		this.networks5 = networks5;
	}

	public Network addNetworks5(Network networks5) {
		getNetworks5().add(networks5);
		networks5.setPartner5(this);

		return networks5;
	}

	public Network removeNetworks5(Network networks5) {
		getNetworks5().remove(networks5);
		networks5.setPartner5(null);

		return networks5;
	}

	public Set<Packpartner> getPackpartners() {
		return this.packpartners;
	}

	public void setPackpartners(Set<Packpartner> packpartners) {
		this.packpartners = packpartners;
	}

	public Packpartner addPackpartner(Packpartner packpartner) {
		getPackpartners().add(packpartner);
		packpartner.setPartner(this);

		return packpartner;
	}

	public Packpartner removePackpartner(Packpartner packpartner) {
		getPackpartners().remove(packpartner);
		packpartner.setPartner(null);

		return packpartner;
	}

	public Set<Groupstaffmember> getGroupstaffmembers() {
		return this.groupstaffmembers;
	}

	public void setGroupstaffmembers(Set<Groupstaffmember> groupstaffmembers) {
		this.groupstaffmembers = groupstaffmembers;
	}

	public Organization getOrganization() {
		return this.organization;
	}

	public void setOrganization(Organization organization) {
		this.organization = organization;
	}

	public Partnerbankingdetail getPartnerbankingdetail() {
		return this.partnerbankingdetail;
	}

	public void setPartnerbankingdetail(Partnerbankingdetail partnerbankingdetail) {
		this.partnerbankingdetail = partnerbankingdetail;
	}

	public Partnercompany getPartnercompany() {
		return this.partnercompany;
	}

	public void setPartnercompany(Partnercompany partnercompany) {
		this.partnercompany = partnercompany;
	}

	public Partnerprofile getPartnerprofile() {
		return this.partnerprofile;
	}

	public void setPartnerprofile(Partnerprofile partnerprofile) {
		this.partnerprofile = partnerprofile;
	}

	public Set<Partnernetwork> getPartnernetworks() {
		return this.partnernetworks;
	}

	public void setPartnernetworks(Set<Partnernetwork> partnernetworks) {
		this.partnernetworks = partnernetworks;
	}

	public Partnernetwork addPartnernetwork(Partnernetwork partnernetwork) {
		getPartnernetworks().add(partnernetwork);
		partnernetwork.setPartner(this);

		return partnernetwork;
	}

	public Partnernetwork removePartnernetwork(Partnernetwork partnernetwork) {
		getPartnernetworks().remove(partnernetwork);
		partnernetwork.setPartner(null);

		return partnernetwork;
	}

	public Set<Personalproductioninvoice> getPersonalproductioninvoices() {
		return this.personalproductioninvoices;
	}

	public void setPersonalproductioninvoices(Set<Personalproductioninvoice> personalproductioninvoices) {
		this.personalproductioninvoices = personalproductioninvoices;
	}

	public Personalproductioninvoice addPersonalproductioninvoice(Personalproductioninvoice personalproductioninvoice) {
		getPersonalproductioninvoices().add(personalproductioninvoice);
		personalproductioninvoice.setPartner(this);

		return personalproductioninvoice;
	}

	public Personalproductioninvoice removePersonalproductioninvoice(Personalproductioninvoice personalproductioninvoice) {
		getPersonalproductioninvoices().remove(personalproductioninvoice);
		personalproductioninvoice.setPartner(null);

		return personalproductioninvoice;
	}

	public Set<Qualificationpartner> getQualificationpartners() {
		return this.qualificationpartners;
	}

	public void setQualificationpartners(Set<Qualificationpartner> qualificationpartners) {
		this.qualificationpartners = qualificationpartners;
	}

	public Qualificationpartner addQualificationpartner(Qualificationpartner qualificationpartner) {
		getQualificationpartners().add(qualificationpartner);
		qualificationpartner.setPartner(this);

		return qualificationpartner;
	}

	public Qualificationpartner removeQualificationpartner(Qualificationpartner qualificationpartner) {
		getQualificationpartners().remove(qualificationpartner);
		qualificationpartner.setPartner(null);

		return qualificationpartner;
	}

	public Set<Recurrenceinvoice> getRecurrenceinvoices() {
		return this.recurrenceinvoices;
	}

	public void setRecurrenceinvoices(Set<Recurrenceinvoice> recurrenceinvoices) {
		this.recurrenceinvoices = recurrenceinvoices;
	}

	public Recurrenceinvoice addRecurrenceinvoice(Recurrenceinvoice recurrenceinvoice) {
		getRecurrenceinvoices().add(recurrenceinvoice);
		recurrenceinvoice.setPartner(this);

		return recurrenceinvoice;
	}

	public Recurrenceinvoice removeRecurrenceinvoice(Recurrenceinvoice recurrenceinvoice) {
		getRecurrenceinvoices().remove(recurrenceinvoice);
		recurrenceinvoice.setPartner(null);

		return recurrenceinvoice;
	}

}